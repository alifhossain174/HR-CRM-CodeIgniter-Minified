-- ---------------------------------------------------------
		--
		-- SIMPLE SQL Dump
		-- 
		-- nawa (at) yahoo (dot) com
		--
		-- Host Connection Info: Localhost via UNIX socket
		-- Generation Time: February 17, 2020 at 12:13 PM ( Asia/Dhaka )
		-- PHP Version: 7.2.27
		--
		-- ---------------------------------------------------------


		SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
		SET time_zone = "+00:00";
		/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
		/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
		/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
		/*!40101 SET NAMES utf8 */;
		

		-- ---------------------------------------------------------
		--
		-- Table structure for table : `ci_sessions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_advance_salaries`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_advance_salaries` (
  `advance_salary_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `month_year` varchar(255) NOT NULL,
  `advance_amount` varchar(255) NOT NULL,
  `one_time_deduct` varchar(50) NOT NULL,
  `monthly_installment` varchar(255) NOT NULL,
  `total_paid` varchar(255) NOT NULL,
  `reason` text NOT NULL,
  `status` int(11) DEFAULT NULL,
  `is_deducted_from_salary` int(11) DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`advance_salary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_announcements`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_announcements` (
  `announcement_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `company_id` int(111) NOT NULL,
  `location_id` int(11) NOT NULL,
  `department_id` int(111) NOT NULL,
  `published_by` int(111) NOT NULL,
  `summary` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_notify` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`announcement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_assets`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_assets` (
  `assets_id` int(111) NOT NULL AUTO_INCREMENT,
  `assets_category_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `company_asset_code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `purchase_date` varchar(255) NOT NULL,
  `invoice_number` varchar(255) NOT NULL,
  `manufacturer` varchar(255) NOT NULL,
  `serial_number` varchar(255) NOT NULL,
  `warranty_end_date` varchar(255) NOT NULL,
  `asset_note` text NOT NULL,
  `asset_image` varchar(255) NOT NULL,
  `is_working` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`assets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_assets_categories`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_assets_categories` (
  `assets_category_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`assets_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_assets_categories`
		--
		INSERT INTO `xin_assets_categories` (`assets_category_id`, `company_id`, `category_name`, `created_at`) VALUES
(1, 1, 'Laptop', '05-04-2018 03:03:31');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_attendance_time`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_attendance_time` (
  `time_attendance_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `attendance_date` varchar(255) NOT NULL,
  `clock_in` varchar(255) NOT NULL,
  `clock_in_ip_address` varchar(255) NOT NULL,
  `clock_out` varchar(255) NOT NULL,
  `clock_out_ip_address` varchar(255) NOT NULL,
  `clock_in_out` varchar(255) NOT NULL,
  `clock_in_latitude` varchar(150) NOT NULL,
  `clock_in_longitude` varchar(150) NOT NULL,
  `clock_out_latitude` varchar(150) NOT NULL,
  `clock_out_longitude` varchar(150) NOT NULL,
  `time_late` varchar(255) NOT NULL,
  `early_leaving` varchar(255) NOT NULL,
  `overtime` varchar(255) NOT NULL,
  `total_work` varchar(255) NOT NULL,
  `total_rest` varchar(255) NOT NULL,
  `attendance_status` varchar(100) NOT NULL,
  PRIMARY KEY (`time_attendance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_attendance_time`
		--
		INSERT INTO `xin_attendance_time` (`time_attendance_id`, `employee_id`, `attendance_date`, `clock_in`, `clock_in_ip_address`, `clock_out`, `clock_out_ip_address`, `clock_in_out`, `clock_in_latitude`, `clock_in_longitude`, `clock_out_latitude`, `clock_out_longitude`, `time_late`, `early_leaving`, `overtime`, `total_work`, `total_rest`, `attendance_status`) VALUES
(1, 5, '2019-04-17', '2019-04-17 10:36:38', '::1', '2019-04-17 10:37:36', '::1', 0, 31.450726399999997, 74.2940672, 31.450726399999997, 74.2940672, '2019-04-17 10:36:38', '2019-04-17 10:37:36', '2019-04-17 10:37:36', '0:0', '', 'Present'),
(2, 6, '2020-02-17', '2020-02-17 10:29:11', '103.142.68.150', '', '', 1, 23.6164, 90.5301, '', '', '2020-02-17 10:29:11', '2020-02-17 10:29:11', '2020-02-17 10:29:11', '', '', 'Present'),
(3, 21, '2020-02-17', '2020-02-17 10:38:57', '103.142.68.150', '', '', 1, 23.6164, 90.5301, '', '', '2020-02-17 10:38:57', '2020-02-17 10:38:57', '2020-02-17 10:38:57', '', '', 'Present'),
(4, 19, '2020-02-17', '2020-02-17 10:40:54', '103.142.68.150', '', '', 1, 23.6164, 90.5301, '', '', '2020-02-17 10:40:54', '2020-02-17 10:40:54', '2020-02-17 10:40:54', '', '', 'Present');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_attendance_time_request`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_attendance_time_request` (
  `time_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `request_date` varchar(255) NOT NULL,
  `request_date_request` varchar(255) NOT NULL,
  `request_clock_in` varchar(200) NOT NULL,
  `request_clock_out` varchar(200) NOT NULL,
  `total_hours` varchar(255) NOT NULL,
  `request_reason` text NOT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`time_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_award_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_award_type` (
  `award_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `award_type` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`award_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_award_type`
		--
		INSERT INTO `xin_award_type` (`award_type_id`, `company_id`, `award_type`, `created_at`) VALUES
(1, 1, 'Performer of the Month', '22-03-2018 01:33:57'),
(2, 0, 'Performer of the Year', '16-02-2020 12:46:34'),
(4, 0, 'Goal Achievement Award', '16-02-2020 09:29:18');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_awards`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_awards` (
  `award_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(200) NOT NULL,
  `award_type_id` int(200) NOT NULL,
  `gift_item` varchar(200) NOT NULL,
  `cash_price` varchar(200) NOT NULL,
  `award_photo` varchar(255) NOT NULL,
  `award_month_year` varchar(200) NOT NULL,
  `award_information` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`award_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_chat_messages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_chat_messages` (
  `message_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_id` varchar(40) NOT NULL DEFAULT '',
  `to_id` varchar(50) NOT NULL DEFAULT '',
  `message_frm` varchar(255) NOT NULL,
  `is_read` int(11) NOT NULL DEFAULT 0,
  `message_content` longtext NOT NULL,
  `message_date` varchar(255) DEFAULT NULL,
  `recd` tinyint(1) NOT NULL DEFAULT 0,
  `message_type` varchar(255) NOT NULL DEFAULT '',
  `department_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_chat_messages`
		--
		INSERT INTO `xin_chat_messages` (`message_id`, `from_id`, `to_id`, `message_frm`, `is_read`, `message_content`, `message_date`, `recd`, `message_type`, `department_id`, `location_id`) VALUES
(1, 6, 12, 12, 0, 'Hi', '2020-02-16 10:57:41', 0, '', 0, 0),
(2, 9, 18, 18, 0, 'hi', '2020-02-16 19:24:20', 0, '', 0, 0),
(3, 7, 6, 6, 1, 'hi', '2020-02-16 21:22:26', 0, '', 0, 0),
(4, 7, 6, 6, 1, 'hi', '2020-02-16 21:22:50', 0, '', 0, 0),
(5, 6, 7, 7, 1, 'hello', '2020-02-16 21:22:59', 0, '', 0, 0),
(6, 14, 9, 9, 1, 'hi bro', '2020-02-17 11:03:52', 0, '', 0, 0),
(7, 9, 14, 14, 0, 'vai msg er notification dey na', '2020-02-17 11:43:44', 0, '', 0, 0);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_clients`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_clients` (
  `client_id` int(111) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `client_username` varchar(255) NOT NULL,
  `client_password` varchar(255) NOT NULL,
  `client_profile` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `is_changed` int(11) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `website_url` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(111) NOT NULL,
  `is_active` int(11) NOT NULL,
  `last_logout_date` varchar(255) NOT NULL,
  `last_login_date` varchar(255) NOT NULL,
  `last_login_ip` varchar(255) NOT NULL,
  `is_logged_in` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_clients`
		--
		INSERT INTO `xin_clients` (`client_id`, `type`, `name`, `email`, `client_username`, `client_password`, `client_profile`, `contact_number`, `company_name`, `is_changed`, `gender`, `website_url`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `is_active`, `last_logout_date`, `last_login_date`, `last_login_ip`, `is_logged_in`, `created_at`) VALUES
(2, '', 'Mostaim', 'mostaim.murad@gmail.com', '', '$2y$12$IdY6Lp09ykjwRN7ewBeql.lcprJclp27m31v/uCgcY6Yg4GzsMX/i', 'client_photo_1581778695.jpg', 01723221999, 'Softifybd', 0, '', 'www.softifybd.net', 'Hazi Motaleb Plaza', 'Bandar', 'Narayanganj', 'Dhaka', 1410, 18, 1, '15-02-2020 22:02:34', '17-02-2020 11:38:41', '103.142.68.222', 1, '2020-02-15 20:58:15'),
(3, '', 'Rubai Saleh', 'rubaiithegreat@gmail.com', '', '$2y$12$xeIecZTi6gObVhk6cT69r.C/QTljSNP3zyPcxs7Ciw90WVhbXrzcS', '', 0481304839, 'A1 Remidial Pty Ltd.', 0, '', '', '49 Loch Street,', '', 'Loch Street', 'Loch Street', '', 13, 1, '', '', '', 0, '2020-02-17 11:22:50');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_companies`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_companies` (
  `company_id` int(111) NOT NULL AUTO_INCREMENT,
  `type_id` int(111) NOT NULL,
  `name` varchar(255) NOT NULL,
  `trading_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `registration_no` varchar(255) NOT NULL,
  `government_tax` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `website_url` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(111) NOT NULL,
  `is_active` int(11) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_companies`
		--
		INSERT INTO `xin_companies` (`company_id`, `type_id`, `name`, `trading_name`, `username`, `password`, `registration_no`, `government_tax`, `email`, `logo`, `contact_number`, `website_url`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `is_active`, `added_by`, `created_at`) VALUES
(1, 5, 'SoftifyBD Ltd', 'SoftifyBD Ltd', 'SoftifyBD', '', '', '', 'softifybd@gmail.com', 'logo_1581764398.png', 01730797262, 'www.softifybd.com', 'Hazi Motaleb Plaza, S.S. Shah Road', 'Bandar', 'Narayanganj', 'Dhaka', 1410, 18, 0, 1, '22-05-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_company_documents`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_company_documents` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_type_id` int(11) NOT NULL,
  `license_name` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `expiry_date` varchar(255) NOT NULL,
  `license_number` varchar(255) NOT NULL,
  `license_notification` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `document` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_company_info`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_company_info` (
  `company_info_id` int(111) NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) NOT NULL,
  `logo_second` varchar(255) NOT NULL,
  `sign_in_logo` varchar(255) NOT NULL,
  `favicon` varchar(255) NOT NULL,
  `website_url` mediumtext NOT NULL,
  `starting_year` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_email` varchar(255) NOT NULL,
  `company_contact` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(111) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`company_info_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_company_info`
		--
		INSERT INTO `xin_company_info` (`company_info_id`, `logo`, `logo_second`, `sign_in_logo`, `favicon`, `website_url`, `starting_year`, `company_name`, `company_email`, `company_contact`, `contact_person`, `email`, `phone`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `updated_at`) VALUES
(1, 'logo_1581879480.png', 'logo2_1520609223.png', 'signin_logo_1581880089.png', 'favicon_1581879700.png', '', '', 'SoftifyBD', '', '', 'Mostaim Billah Murad', 'softifybd@gmail.com', 01730797262, 'Hazi Motaleb Plaza, S.S. Shah Road', 'Bandar', 'Narayanganj', 'Dhaka', 1410, 18, '2017-05-20 12:05:53');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_company_policy`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_company_policy` (
  `policy_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(111) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`policy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_company_policy`
		--
		INSERT INTO `xin_company_policy` (`policy_id`, `company_id`, `title`, `description`, `attachment`, `added_by`, `created_at`) VALUES
(1, 1, 'Smoke-Free Work', '&lt;p&gt;Smoke-Free Work Environment Policy Close&lt;/p&gt;', '', 1, '28-02-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_company_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_company_type` (
  `type_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_company_type`
		--
		INSERT INTO `xin_company_type` (`type_id`, `name`, `created_at`) VALUES
(3, 'Partnership', ''),
(5, 'Private Limited Company', ''),
(6, 'Sole Proprietorship', '16-02-2020 12:59:22');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_contract_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_contract_type` (
  `contract_type_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`contract_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_contract_type`
		--
		INSERT INTO `xin_contract_type` (`contract_type_id`, `company_id`, `name`, `created_at`) VALUES
(1, 1, 'Permanent', '05-04-2018 06:10:32'),
(2, 0, 'Fixed-Term', '16-02-2020 05:47:57'),
(3, 0, 'Probationary', '16-02-2020 05:50:04'),
(4, 0, 'Casual', '16-02-2020 05:53:49'),
(5, 0, 'Temporary', '16-02-2020 05:54:40');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_countries`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(255) NOT NULL,
  `country_name` varchar(255) NOT NULL,
  `country_flag` varchar(255) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_countries`
		--
		INSERT INTO `xin_countries` (`country_id`, `country_code`, `country_name`, `country_flag`) VALUES
(1, +93, 'Afghanistan', 'flag_1500831780.gif'),
(2, +355, 'Albania', 'flag_1500831815.gif'),
(3, 'DZ', 'Algeria', ''),
(4, 'DS', 'American Samoa', ''),
(5, 'AD', 'Andorra', ''),
(6, 'AO', 'Angola', ''),
(7, 'AI', 'Anguilla', ''),
(8, 'AQ', 'Antarctica', ''),
(9, 'AG', 'Antigua and Barbuda', ''),
(10, 'AR', 'Argentina', ''),
(11, 'AM', 'Armenia', ''),
(12, 'AW', 'Aruba', ''),
(13, 'AU', 'Australia', ''),
(14, 'AT', 'Austria', ''),
(15, 'AZ', 'Azerbaijan', ''),
(16, 'BS', 'Bahamas', ''),
(17, 'BH', 'Bahrain', ''),
(18, 'BD', 'Bangladesh', ''),
(19, 'BB', 'Barbados', ''),
(20, 'BY', 'Belarus', ''),
(21, 'BE', 'Belgium', ''),
(22, 'BZ', 'Belize', ''),
(23, 'BJ', 'Benin', ''),
(24, 'BM', 'Bermuda', ''),
(25, 'BT', 'Bhutan', ''),
(26, 'BO', 'Bolivia', ''),
(27, 'BA', 'Bosnia and Herzegovina', ''),
(28, 'BW', 'Botswana', ''),
(29, 'BV', 'Bouvet Island', ''),
(30, 'BR', 'Brazil', ''),
(31, 'IO', 'British Indian Ocean Territory', ''),
(32, 'BN', 'Brunei Darussalam', ''),
(33, 'BG', 'Bulgaria', ''),
(34, 'BF', 'Burkina Faso', ''),
(35, 'BI', 'Burundi', ''),
(36, 'KH', 'Cambodia', ''),
(37, 'CM', 'Cameroon', ''),
(38, 'CA', 'Canada', ''),
(39, 'CV', 'Cape Verde', ''),
(40, 'KY', 'Cayman Islands', ''),
(41, 'CF', 'Central African Republic', ''),
(42, 'TD', 'Chad', ''),
(43, 'CL', 'Chile', ''),
(44, 'CN', 'China', ''),
(45, 'CX', 'Christmas Island', ''),
(46, 'CC', 'Cocos (Keeling) Islands', ''),
(47, 'CO', 'Colombia', ''),
(48, 'KM', 'Comoros', ''),
(49, 'CG', 'Congo', ''),
(50, 'CK', 'Cook Islands', ''),
(51, 'CR', 'Costa Rica', ''),
(52, 'HR', 'Croatia (Hrvatska)', ''),
(53, 'CU', 'Cuba', ''),
(54, 'CY', 'Cyprus', ''),
(55, 'CZ', 'Czech Republic', ''),
(56, 'DK', 'Denmark', ''),
(57, 'DJ', 'Djibouti', ''),
(58, 'DM', 'Dominica', ''),
(59, 'DO', 'Dominican Republic', ''),
(60, 'TP', 'East Timor', ''),
(61, 'EC', 'Ecuador', ''),
(62, 'EG', 'Egypt', ''),
(63, 'SV', 'El Salvador', ''),
(64, 'GQ', 'Equatorial Guinea', ''),
(65, 'ER', 'Eritrea', ''),
(66, 'EE', 'Estonia', ''),
(67, 'ET', 'Ethiopia', ''),
(68, 'FK', 'Falkland Islands (Malvinas)', ''),
(69, 'FO', 'Faroe Islands', ''),
(70, 'FJ', 'Fiji', ''),
(71, 'FI', 'Finland', ''),
(72, 'FR', 'France', ''),
(73, 'FX', 'France, Metropolitan', ''),
(74, 'GF', 'French Guiana', ''),
(75, 'PF', 'French Polynesia', ''),
(76, 'TF', 'French Southern Territories', ''),
(77, 'GA', 'Gabon', ''),
(78, 'GM', 'Gambia', ''),
(79, 'GE', 'Georgia', ''),
(80, 'DE', 'Germany', ''),
(81, 'GH', 'Ghana', ''),
(82, 'GI', 'Gibraltar', ''),
(83, 'GK', 'Guernsey', ''),
(84, 'GR', 'Greece', ''),
(85, 'GL', 'Greenland', ''),
(86, 'GD', 'Grenada', ''),
(87, 'GP', 'Guadeloupe', ''),
(88, 'GU', 'Guam', ''),
(89, 'GT', 'Guatemala', ''),
(90, 'GN', 'Guinea', ''),
(91, 'GW', 'Guinea-Bissau', ''),
(92, 'GY', 'Guyana', ''),
(93, 'HT', 'Haiti', ''),
(94, 'HM', 'Heard and Mc Donald Islands', ''),
(95, 'HN', 'Honduras', ''),
(96, 'HK', 'Hong Kong', ''),
(97, 'HU', 'Hungary', ''),
(98, 'IS', 'Iceland', ''),
(99, 'IN', 'India', ''),
(100, 'IM', 'Isle of Man', ''),
(101, 'ID', 'Indonesia', ''),
(102, 'IR', 'Iran (Islamic Republic of)', ''),
(103, 'IQ', 'Iraq', ''),
(104, 'IE', 'Ireland', ''),
(105, 'IL', 'Israel', ''),
(106, 'IT', 'Italy', ''),
(107, 'CI', 'Ivory Coast', ''),
(108, 'JE', 'Jersey', ''),
(109, 'JM', 'Jamaica', ''),
(110, 'JP', 'Japan', ''),
(111, 'JO', 'Jordan', ''),
(112, 'KZ', 'Kazakhstan', ''),
(113, 'KE', 'Kenya', ''),
(114, 'KI', 'Kiribati', ''),
(115, 'KP', 'Korea, Democratic People''s Republic of', ''),
(116, 'KR', 'Korea, Republic of', ''),
(117, 'XK', 'Kosovo', ''),
(118, 'KW', 'Kuwait', ''),
(119, 'KG', 'Kyrgyzstan', ''),
(120, 'LA', 'Lao People''s Democratic Republic', ''),
(121, 'LV', 'Latvia', ''),
(122, 'LB', 'Lebanon', ''),
(123, 'LS', 'Lesotho', ''),
(124, 'LR', 'Liberia', ''),
(125, 'LY', 'Libyan Arab Jamahiriya', ''),
(126, 'LI', 'Liechtenstein', ''),
(127, 'LT', 'Lithuania', ''),
(128, 'LU', 'Luxembourg', ''),
(129, 'MO', 'Macau', ''),
(130, 'MK', 'Macedonia', ''),
(131, 'MG', 'Madagascar', ''),
(132, 'MW', 'Malawi', ''),
(133, 'MY', 'Malaysia', ''),
(134, 'MV', 'Maldives', ''),
(135, 'ML', 'Mali', ''),
(136, 'MT', 'Malta', ''),
(137, 'MH', 'Marshall Islands', ''),
(138, 'MQ', 'Martinique', ''),
(139, 'MR', 'Mauritania', ''),
(140, 'MU', 'Mauritius', ''),
(141, 'TY', 'Mayotte', ''),
(142, 'MX', 'Mexico', ''),
(143, 'FM', 'Micronesia, Federated States of', ''),
(144, 'MD', 'Moldova, Republic of', ''),
(145, 'MC', 'Monaco', ''),
(146, 'MN', 'Mongolia', ''),
(147, 'ME', 'Montenegro', ''),
(148, 'MS', 'Montserrat', ''),
(149, 'MA', 'Morocco', ''),
(150, 'MZ', 'Mozambique', ''),
(151, 'MM', 'Myanmar', ''),
(152, 'NA', 'Namibia', ''),
(153, 'NR', 'Nauru', ''),
(154, 'NP', 'Nepal', ''),
(155, 'NL', 'Netherlands', ''),
(156, 'AN', 'Netherlands Antilles', ''),
(157, 'NC', 'New Caledonia', ''),
(158, 'NZ', 'New Zealand', ''),
(159, 'NI', 'Nicaragua', ''),
(160, 'NE', 'Niger', ''),
(161, 'NG', 'Nigeria', ''),
(162, 'NU', 'Niue', ''),
(163, 'NF', 'Norfolk Island', ''),
(164, 'MP', 'Northern Mariana Islands', ''),
(165, 'NO', 'Norway', ''),
(166, 'OM', 'Oman', ''),
(167, 'PK', 'Pakistan', ''),
(168, 'PW', 'Palau', ''),
(169, 'PS', 'Palestine', ''),
(170, 'PA', 'Panama', ''),
(171, 'PG', 'Papua New Guinea', ''),
(172, 'PY', 'Paraguay', ''),
(173, 'PE', 'Peru', ''),
(174, 'PH', 'Philippines', ''),
(175, 'PN', 'Pitcairn', ''),
(176, 'PL', 'Poland', ''),
(177, 'PT', 'Portugal', ''),
(178, 'PR', 'Puerto Rico', ''),
(179, 'QA', 'Qatar', ''),
(180, 'RE', 'Reunion', ''),
(181, 'RO', 'Romania', ''),
(182, 'RU', 'Russian Federation', ''),
(183, 'RW', 'Rwanda', ''),
(184, 'KN', 'Saint Kitts and Nevis', ''),
(185, 'LC', 'Saint Lucia', ''),
(186, 'VC', 'Saint Vincent and the Grenadines', ''),
(187, 'WS', 'Samoa', ''),
(188, 'SM', 'San Marino', ''),
(189, 'ST', 'Sao Tome and Principe', ''),
(190, 'SA', 'Saudi Arabia', ''),
(191, 'SN', 'Senegal', ''),
(192, 'RS', 'Serbia', ''),
(193, 'SC', 'Seychelles', ''),
(194, 'SL', 'Sierra Leone', ''),
(195, 'SG', 'Singapore', ''),
(196, 'SK', 'Slovakia', ''),
(197, 'SI', 'Slovenia', ''),
(198, 'SB', 'Solomon Islands', ''),
(199, 'SO', 'Somalia', ''),
(200, 'ZA', 'South Africa', ''),
(201, 'GS', 'South Georgia South Sandwich Islands', ''),
(202, 'ES', 'Spain', ''),
(203, 'LK', 'Sri Lanka', ''),
(204, 'SH', 'St. Helena', ''),
(205, 'PM', 'St. Pierre and Miquelon', ''),
(206, 'SD', 'Sudan', ''),
(207, 'SR', 'Suriname', ''),
(208, 'SJ', 'Svalbard and Jan Mayen Islands', ''),
(209, 'SZ', 'Swaziland', ''),
(210, 'SE', 'Sweden', ''),
(211, 'CH', 'Switzerland', ''),
(212, 'SY', 'Syrian Arab Republic', ''),
(213, 'TW', 'Taiwan', ''),
(214, 'TJ', 'Tajikistan', ''),
(215, 'TZ', 'Tanzania, United Republic of', ''),
(216, 'TH', 'Thailand', ''),
(217, 'TG', 'Togo', ''),
(218, 'TK', 'Tokelau', ''),
(219, 'TO', 'Tonga', ''),
(220, 'TT', 'Trinidad and Tobago', ''),
(221, 'TN', 'Tunisia', ''),
(222, 'TR', 'Turkey', ''),
(223, 'TM', 'Turkmenistan', ''),
(224, 'TC', 'Turks and Caicos Islands', ''),
(225, 'TV', 'Tuvalu', ''),
(226, 'UG', 'Uganda', ''),
(227, 'UA', 'Ukraine', ''),
(228, 'AE', 'United Arab Emirates', ''),
(229, 'GB', 'United Kingdom', ''),
(230, 'US', 'United States', ''),
(231, 'UM', 'United States minor outlying islands', ''),
(232, 'UY', 'Uruguay', ''),
(233, 'UZ', 'Uzbekistan', ''),
(234, 'VU', 'Vanuatu', ''),
(235, 'VA', 'Vatican City State', ''),
(236, 'VE', 'Venezuela', ''),
(237, 'VN', 'Vietnam', ''),
(238, 'VG', 'Virgin Islands (British)', ''),
(239, 'VI', 'Virgin Islands (U.S.)', ''),
(240, 'WF', 'Wallis and Futuna Islands', ''),
(241, 'EH', 'Western Sahara', ''),
(242, 'YE', 'Yemen', ''),
(243, 'ZR', 'Zaire', ''),
(244, 'ZM', 'Zambia', ''),
(245, 'ZW', 'Zimbabwe', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_currencies`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_currencies` (
  `currency_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  PRIMARY KEY (`currency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_currencies`
		--
		INSERT INTO `xin_currencies` (`currency_id`, `company_id`, `name`, `code`, `symbol`) VALUES
(1, 1, 'Taka', 'BDT', '?'),
(2, 0, 'Dollar', 'USD', '$');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_currency_converter`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_currency_converter` (
  `currency_converter_id` int(11) NOT NULL AUTO_INCREMENT,
  `usd_currency` varchar(11) NOT NULL DEFAULT '1',
  `to_currency_title` varchar(200) NOT NULL,
  `to_currency_rate` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`currency_converter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_currency_converter`
		--
		INSERT INTO `xin_currency_converter` (`currency_converter_id`, `usd_currency`, `to_currency_title`, `to_currency_rate`, `created_at`) VALUES
(1, 1, 'MYR', 4.11, '17-08-2018 03:29:58');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_database_backup`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_database_backup` (
  `backup_id` int(111) NOT NULL AUTO_INCREMENT,
  `backup_file` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`backup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_database_backup`
		--
		INSERT INTO `xin_database_backup` (`backup_id`, `backup_file`, `created_at`) VALUES
(1, 'backup_16-02-2020_00_39_37.sql.gz', '16-02-2020 00:39:37'),
(2, 'backup_16-02-2020_10_12_53.sql.gz', '16-02-2020 10:12:53');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_departments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_departments` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(200) NOT NULL,
  `company_id` int(11) NOT NULL,
  `location_id` int(111) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_departments`
		--
		INSERT INTO `xin_departments` (`department_id`, `department_name`, `company_id`, `location_id`, `employee_id`, `added_by`, `created_at`, `status`) VALUES
(2, 'AppAdmin', 1, 2, 6, 1, '17-03-2018', 1),
(3, 'System Administration', 1, 2, 7, 1, '2020-02-15 17:07:19', 1),
(4, 'Development', 1, 2, 7, 1, '2020-02-15 17:13:18', 1),
(5, 'Human Resource', 1, 2, 23, 6, '2020-02-15 18:30:09', 1),
(6, 'Support', 1, 2, 10, 6, '2020-02-15 19:27:17', 1),
(7, 'Sales & Marketing', 1, 2, 6, 6, '2020-02-15 19:27:45', 1),
(8, 'Research & Development', 1, 2, 6, 6, '2020-02-15 19:30:00', 1),
(9, 'Branding', 1, 2, 12, 6, '2020-02-16 10:22:00', 1),
(10, 'Graphics', 1, 2, 19, 6, '2020-02-16 13:14:30', 1),
(11, 'Management', 1, 2, 6, 1, '2020-02-16 15:34:36', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_designations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_designations` (
  `designation_id` int(11) NOT NULL AUTO_INCREMENT,
  `top_designation_id` int(11) NOT NULL DEFAULT 0,
  `department_id` int(200) NOT NULL,
  `sub_department_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `designation_name` varchar(200) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`designation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_designations`
		--
		INSERT INTO `xin_designations` (`designation_id`, `top_designation_id`, `department_id`, `sub_department_id`, `company_id`, `designation_name`, `added_by`, `created_at`, `status`) VALUES
(9, 0, 4, 0, 1, 'Software Developer', 1, '06-03-2018', 1),
(10, 0, 2, 0, 1, 'Admin', 1, '18-03-2018', 1),
(11, 0, 3, 0, 1, 'CEO & Managing Director', 1, '15-02-2020', 1),
(12, 0, 3, 0, 1, 'Director', 1, '15-02-2020', 1),
(13, 0, 3, 0, 1, 'Chairman', 6, '15-02-2020', 1),
(14, 0, 9, 0, 1, 'Brand Manager', 6, '16-02-2020', 1),
(15, 0, 4, 0, 1, 'Web Designer/Developer', 6, '16-02-2020', 1),
(16, 0, 10, 0, 1, 'Senior Graphic Designer', 6, '16-02-2020', 1),
(17, 0, 6, 0, 1, 'Customer Relationship Executive', 6, '16-02-2020', 1),
(18, 0, 7, 0, 1, 'Marketing Executive', 6, '16-02-2020', 1),
(19, 0, 5, 0, 1, 'Head of HR', 1, '16-02-2020', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_document_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_document_type` (
  `document_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `document_type` varchar(255) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`document_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_document_type`
		--
		INSERT INTO `xin_document_type` (`document_type_id`, `company_id`, `document_type`, `created_at`) VALUES
(1, 1, 'Driving License', '09-05-2018 12:34:55'),
(2, 0, 'NID', '16-02-2020 12:40:44'),
(3, 0, 'Birth Certificate', '16-02-2020 12:41:09'),
(4, 0, 'Academic Certificate', '16-02-2020 12:41:47'),
(5, 0, 'Academic Transcript', '16-02-2020 06:03:08'),
(6, 0, 'Passport', '16-02-2020 06:03:37'),
(7, 0, 'Experience Certificate', '16-02-2020 06:05:12'),
(8, 0, 'TIN Certificate', '16-02-2020 11:51:35'),
(9, 0, 'Reference Letter', '16-02-2020 11:53:32');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_email_configuration`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_email_configuration` (
  `email_config_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_type` enum('phpmail','smtp','codeigniter') COLLATE utf8_unicode_ci NOT NULL,
  `smtp_host` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `smtp_username` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `smtp_password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `smtp_port` int(11) NOT NULL,
  `smtp_secure` enum('tls','ssl') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`email_config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

		--
		-- Dumping data for table `xin_email_configuration`
		--
		INSERT INTO `xin_email_configuration` (`email_config_id`, `email_type`, `smtp_host`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_secure`) VALUES
(1, 'smtp', 'smtp.gmail.com', 'softifybd@gmail.com', 'Rifat+Murad@BD2019', 587, 'ssl');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_email_template`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_email_template` (
  `template_id` int(111) NOT NULL AUTO_INCREMENT,
  `template_code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_email_template`
		--
		INSERT INTO `xin_email_template` (`template_id`, `template_code`, `name`, `subject`, `message`, `status`) VALUES
(2, 'code1', 'Forgot Password', 'Forgot Password', '&lt;p&gt;There was recently a request for password for your {var site_name}�account.&lt;/p&gt;&lt;p&gt;If this was a mistake, just ignore this email and nothing will happen.&lt;br&gt;&lt;/p&gt;&lt;p&gt;To reset your password, visit the following link &lt;a href=\&quot;\\\\\&quot; admin=\&quot;\&quot; auth=\&quot;\&quot; password=\&quot;\&quot; change=\&quot;true&amp;email={var\&quot; title=\&quot;\\\\\&quot;&gt;&lt;a href=\&quot;{var site_url}admin/auth/reset_password/?change=true&amp;email={var email}\&quot; title=\&quot;reset_password\&quot;&gt;Reset Password&lt;/a&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; admin=\&quot;\\\\\&quot; auth=\&quot;\\\\\&quot; title=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Thank you,&lt;br&gt;The {var site_name} Team&lt;/p&gt;', 1),
(3, 'code2', 'New Project', 'New Project', '&lt;p&gt;Dear {var name},&lt;/p&gt;&lt;p&gt;New project has been assigned to you.&lt;/p&gt;&lt;p&gt;Project Name: {var project_name}&lt;/p&gt;&lt;p&gt;Project Start Date:&amp;nbsp;&lt;span 1rem;\\\&quot;=\&quot;\&quot;&gt;{var project_start_date}&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span 1rem;\\\&quot;=\&quot;\&quot;&gt;Thank you,&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(5, 'code3', 'Leave Request ', 'A Leave Request from you', '&lt;p&gt;Dear Admin,&lt;/p&gt;&lt;p&gt;{var employee_name}�wants a leave from you.&lt;/p&gt;&lt;p&gt;You can view this leave request by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;br&gt;&lt;br&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(6, 'code4', 'Leave Approve', 'Your leave request has been approved', '&lt;p&gt;Your leave request has been approved&lt;/p&gt;&lt;p&gt;&lt;span xss=removed&gt;Congratulations! Your leave request from&lt;/span&gt;&lt;font color=\&quot;\\\\\&quot; face=\&quot;\\\\\&quot; arial,=\&quot;\&quot; verdana,=\&quot;\&quot; trebuchet=\&quot;\&quot;&gt;�&lt;/font&gt;{var leave_start_date}�to�{var leave_end_date}�has been approved by your company management.&lt;/p&gt;&lt;p&gt;Check here&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;br&gt;&lt;/p&gt;&lt;p&gt;Regards&lt;br&gt;The {var site_name} Team&lt;/p&gt;', 1),
(7, 'code5', 'Leave Reject', 'Your leave request has been Rejected', '&lt;p&gt;Your leave request has been Rejected&lt;/p&gt;&lt;p&gt;Unfortunately !�Your leave request from�{var leave_start_date}�to�{var leave_end_date}�has been Rejected by your company management.&lt;/p&gt;&lt;p&gt;Check here&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;br&gt;&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(8, 'code6', 'Welcome Email ', 'Welcome Email ', '&lt;p&gt;Hello�{var employee_name},&lt;/p&gt;&lt;p&gt;Welcome to�{var site_name}�.Thanks for joining�{var site_name}. We listed your sign in details below, make sure you keep them safe.&lt;/p&gt;&lt;p&gt;Your Username: {var username}&lt;/p&gt;&lt;p&gt;Your Employee ID: {var employee_id}&lt;br&gt;Your Email Address: {var email}&lt;br&gt;Your Password: {var password}&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; hr=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; admin=\&quot;\&quot;&gt;Login Panel&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn\&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;/p&gt;&lt;p&gt;Have fun!&lt;/p&gt;&lt;p&gt;The�{var site_name}�Team.&lt;/p&gt;', 1),
(9, 'code7', 'Transfer', 'New Transfer', '&lt;p&gt;Hello�{var employee_name},&lt;/p&gt;&lt;p&gt;You have been�transfered to another department and location.&lt;/p&gt;&lt;p&gt;You can view the transfer details by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(10, 'code8', 'Award', 'Award Received', '&lt;p&gt;Hello�{var employee_name},&lt;/p&gt;&lt;p&gt;You have been�awarded�{var award_name}.&lt;/p&gt;&lt;p&gt;You can view this award by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;&lt;span xss=removed&gt;{var site_url}admin/&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(14, 'code9', 'New Task', 'Task assigned', '&lt;p&gt;Dear Employee,&lt;/p&gt;&lt;p&gt;A new task�&lt;span xss=\&quot;\\\\\&quot;&gt;{var task_name}&lt;/span&gt;�has been assigned to you by�&lt;span xss=\&quot;\\\\\&quot;&gt;{var task_assigned_by}&lt;/span&gt;.&lt;/p&gt;&lt;p&gt;You can view this task by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;{var site_url}admin/&lt;/p&gt;&lt;p&gt;Regards,&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(15, 'code10', 'New Inquiry', 'New Inquiry [#{var ticket_code}]', '&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;&lt;span xss=\&quot;removed\&quot;&gt;Dear Admin,&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;&lt;span xss=\&quot;removed\&quot;&gt;Your received a new inquiry.&lt;/span&gt;&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;&lt;span xss=\&quot;removed\&quot;&gt;Inquiry Code: #{var ticket_code}&lt;/span&gt;&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;Status : Open&lt;br&gt;&lt;br&gt;Click on the below link to see the inquiry details and post additional comments.&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;{var site_url}admin/tickets/&lt;br&gt;&lt;br&gt;Regards&lt;/p&gt;&lt;p xss=\&quot;removed\&quot; rgb(51,=\&quot;\\\&quot; font-family:=\&quot;\\\&quot; sans-serif,=\&quot;\\\&quot; arial,=\&quot;\\\&quot; verdana,=\&quot;\\\&quot; trebuchet=\&quot;\\\\\&quot;&gt;The {var site_name} Team&lt;/p&gt;', 1),
(16, 'code11', 'Client Welcome Email', 'Welcome Email', '&lt;p&gt;Hello�{var client_name},&lt;/p&gt;&lt;p&gt;Welcome to�{var site_name}�.Thanks for joining�{var site_name}. We listed your sign in details below, make sure you keep them safe. You can login to your panel using email and password.&lt;/p&gt;&lt;p&gt;Your Email Address: {var email}&lt;br&gt;&lt;/p&gt;&lt;p&gt;Your Password: {var password}&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; hr=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; client=\&quot;\\\\\&quot;&gt;&lt;/a&gt;&lt;a href=\&quot;\\\\\&quot; client=\&quot;\\\\\&quot;&gt;Login Panel&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn\&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}client/&lt;/p&gt;&lt;p&gt;Have fun!&lt;/p&gt;&lt;p&gt;The�{var site_name}�Team.&lt;/p&gt;', 1),
(17, 'code12', 'Password Changed Successfully', 'Password Changed Successfully', '&lt;p&gt;Hello,&lt;/p&gt;&lt;p&gt;Congratulations! Your password has been updated successfully.&lt;/p&gt;&lt;p&gt;Your new password is: {var password}&lt;/p&gt;&lt;p&gt;Thank you,&lt;br&gt;The {var site_name} Team&lt;br&gt;&lt;/p&gt;', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_bankaccount`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_bankaccount` (
  `bankaccount_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `is_primary` int(11) NOT NULL,
  `account_title` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_code` varchar(255) NOT NULL,
  `bank_branch` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`bankaccount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_complaints`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_complaints` (
  `complaint_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `complaint_from` int(111) NOT NULL,
  `title` varchar(255) NOT NULL,
  `complaint_date` varchar(255) NOT NULL,
  `complaint_against` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `status` tinyint(2) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_contacts`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_contacts` (
  `contact_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `relation` varchar(255) NOT NULL,
  `is_primary` int(111) NOT NULL,
  `is_dependent` int(111) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `work_phone` varchar(255) NOT NULL,
  `work_phone_extension` varchar(255) NOT NULL,
  `mobile_phone` varchar(255) NOT NULL,
  `home_phone` varchar(255) NOT NULL,
  `work_email` varchar(255) NOT NULL,
  `personal_email` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_contract`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_contract` (
  `contract_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `contract_type_id` int(111) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `designation_id` int(111) NOT NULL,
  `title` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_documents`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_documents` (
  `document_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `document_type_id` int(111) NOT NULL,
  `date_of_expiry` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `notification_email` varchar(255) NOT NULL,
  `is_alert` tinyint(1) NOT NULL,
  `description` mediumtext NOT NULL,
  `document_file` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_exit`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_exit` (
  `exit_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `exit_date` varchar(255) NOT NULL,
  `exit_type_id` int(111) NOT NULL,
  `exit_interview` int(111) NOT NULL,
  `is_inactivate_account` int(111) NOT NULL,
  `reason` mediumtext NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`exit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_exit_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_exit_type` (
  `exit_type_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`exit_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_employee_exit_type`
		--
		INSERT INTO `xin_employee_exit_type` (`exit_type_id`, `company_id`, `type`, `created_at`) VALUES
(1, 1, 'Personal Reason', ''),
(2, 0, 'Company Need', '16-02-2020 01:09:07');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_immigration`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_immigration` (
  `immigration_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `document_type_id` int(111) NOT NULL,
  `document_number` varchar(255) NOT NULL,
  `document_file` varchar(255) NOT NULL,
  `issue_date` varchar(255) NOT NULL,
  `expiry_date` varchar(255) NOT NULL,
  `country_id` varchar(255) NOT NULL,
  `eligible_review_date` varchar(255) NOT NULL,
  `comments` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`immigration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_leave`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_leave` (
  `leave_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `contract_id` int(111) NOT NULL,
  `casual_leave` varchar(255) NOT NULL,
  `medical_leave` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_location`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_location` (
  `office_location_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `location_id` int(111) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`office_location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_promotions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_promotions` (
  `promotion_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `title` varchar(255) NOT NULL,
  `promotion_date` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`promotion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_qualification`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_qualification` (
  `qualification_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `name` varchar(255) NOT NULL,
  `education_level_id` int(111) NOT NULL,
  `from_year` varchar(255) NOT NULL,
  `language_id` int(111) NOT NULL,
  `to_year` varchar(255) NOT NULL,
  `skill_id` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`qualification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_resignations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_resignations` (
  `resignation_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `notice_date` varchar(255) NOT NULL,
  `resignation_date` varchar(255) NOT NULL,
  `reason` mediumtext NOT NULL,
  `added_by` int(111) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`resignation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_security_level`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_security_level` (
  `security_level_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `security_type` int(11) NOT NULL,
  `date_of_clearance` varchar(200) NOT NULL,
  `expiry_date` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`security_level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_shift`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_shift` (
  `emp_shift_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `shift_id` int(111) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`emp_shift_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_terminations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_terminations` (
  `termination_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `terminated_by` int(111) NOT NULL,
  `termination_type_id` int(111) NOT NULL,
  `termination_date` varchar(255) NOT NULL,
  `notice_date` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` tinyint(2) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`termination_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_transfer`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_transfer` (
  `transfer_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `transfer_date` varchar(255) NOT NULL,
  `transfer_department` int(111) NOT NULL,
  `transfer_location` int(111) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` tinyint(2) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`transfer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_travels`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_travels` (
  `travel_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `visit_purpose` varchar(255) NOT NULL,
  `visit_place` varchar(255) NOT NULL,
  `travel_mode` int(111) DEFAULT NULL,
  `arrangement_type` int(111) DEFAULT NULL,
  `expected_budget` varchar(255) NOT NULL,
  `actual_budget` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` tinyint(2) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`travel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_warnings`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_warnings` (
  `warning_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `warning_to` int(111) NOT NULL,
  `warning_by` int(111) NOT NULL,
  `warning_date` varchar(255) NOT NULL,
  `warning_type_id` int(111) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` tinyint(2) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`warning_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_employee_warnings`
		--
		INSERT INTO `xin_employee_warnings` (`warning_id`, `company_id`, `warning_to`, `warning_by`, `warning_date`, `warning_type_id`, `attachment`, `subject`, `description`, `status`, `created_at`) VALUES
(1, 1, 6, 7, '2020-02-16', 1, '', 'Test', 'xyz', 1, '16-02-2020');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employee_work_experience`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employee_work_experience` (
  `work_experience_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`work_experience_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_employees`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_employees` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(200) NOT NULL,
  `office_shift_id` int(111) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `date_of_birth` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `e_status` int(11) NOT NULL,
  `user_role_id` int(100) NOT NULL,
  `department_id` int(100) NOT NULL,
  `sub_department_id` int(11) NOT NULL,
  `designation_id` int(100) NOT NULL,
  `company_id` int(111) DEFAULT NULL,
  `location_id` int(11) NOT NULL,
  `view_companies_id` varchar(255) NOT NULL,
  `salary_template` varchar(255) NOT NULL,
  `hourly_grade_id` int(111) NOT NULL,
  `monthly_grade_id` int(111) NOT NULL,
  `date_of_joining` varchar(200) NOT NULL,
  `date_of_leaving` varchar(255) NOT NULL,
  `marital_status` varchar(255) NOT NULL,
  `salary` varchar(200) NOT NULL,
  `wages_type` int(11) NOT NULL,
  `basic_salary` varchar(200) NOT NULL DEFAULT '0',
  `daily_wages` varchar(200) NOT NULL DEFAULT '0',
  `salary_ssempee` varchar(200) NOT NULL DEFAULT '0',
  `salary_ssempeer` varchar(200) DEFAULT '0',
  `salary_income_tax` varchar(200) NOT NULL DEFAULT '0',
  `salary_overtime` varchar(200) NOT NULL DEFAULT '0',
  `salary_commission` varchar(200) NOT NULL DEFAULT '0',
  `salary_claims` varchar(200) NOT NULL DEFAULT '0',
  `salary_paid_leave` varchar(200) NOT NULL DEFAULT '0',
  `salary_director_fees` varchar(200) NOT NULL DEFAULT '0',
  `salary_bonus` varchar(200) NOT NULL DEFAULT '0',
  `salary_advance_paid` varchar(200) NOT NULL DEFAULT '0',
  `address` mediumtext NOT NULL,
  `state` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `zipcode` varchar(200) NOT NULL,
  `profile_picture` mediumtext NOT NULL,
  `profile_background` mediumtext NOT NULL,
  `resume` mediumtext NOT NULL,
  `skype_id` varchar(200) NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `facebook_link` mediumtext NOT NULL,
  `twitter_link` mediumtext NOT NULL,
  `blogger_link` mediumtext NOT NULL,
  `linkdedin_link` mediumtext NOT NULL,
  `google_plus_link` mediumtext NOT NULL,
  `instagram_link` varchar(255) NOT NULL,
  `pinterest_link` varchar(255) NOT NULL,
  `youtube_link` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `last_login_date` varchar(255) NOT NULL,
  `last_logout_date` varchar(255) NOT NULL,
  `last_login_ip` varchar(255) NOT NULL,
  `is_logged_in` int(111) NOT NULL,
  `online_status` int(111) NOT NULL,
  `fixed_header` varchar(150) NOT NULL,
  `compact_sidebar` varchar(150) NOT NULL,
  `boxed_wrapper` varchar(150) NOT NULL,
  `leave_categories` varchar(255) NOT NULL DEFAULT '0',
  `ethnicity_type` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_employees`
		--
		INSERT INTO `xin_employees` (`user_id`, `employee_id`, `office_shift_id`, `first_name`, `last_name`, `username`, `email`, `password`, `date_of_birth`, `gender`, `e_status`, `user_role_id`, `department_id`, `sub_department_id`, `designation_id`, `company_id`, `location_id`, `view_companies_id`, `salary_template`, `hourly_grade_id`, `monthly_grade_id`, `date_of_joining`, `date_of_leaving`, `marital_status`, `salary`, `wages_type`, `basic_salary`, `daily_wages`, `salary_ssempee`, `salary_ssempeer`, `salary_income_tax`, `salary_overtime`, `salary_commission`, `salary_claims`, `salary_paid_leave`, `salary_director_fees`, `salary_bonus`, `salary_advance_paid`, `address`, `state`, `city`, `zipcode`, `profile_picture`, `profile_background`, `resume`, `skype_id`, `contact_no`, `facebook_link`, `twitter_link`, `blogger_link`, `linkdedin_link`, `google_plus_link`, `instagram_link`, `pinterest_link`, `youtube_link`, `is_active`, `last_login_date`, `last_logout_date`, `last_login_ip`, `is_logged_in`, `online_status`, `fixed_header`, `compact_sidebar`, `boxed_wrapper`, `leave_categories`, `ethnicity_type`, `created_at`) VALUES
(1, 'fionagrace', 1, 'Softify', 'BD', 'fionagrace', 'softifybd@gmail.com', '$2y$12$maSHOeIQvZMBw3ChhFGfJe72gXPsFc9mCbssVB78KMIbwMSNl5O8i', '1985-04-22', 'Male', 0, 1, 2, 0, 10, 1, 1, 0, 'monthly', 0, 0, '2018-02-01', '', 'Married', '', 1, 1000, 0, 8, 17, 10, 0, 1, 2, 3, 0, 0, 0, 'Test Address', '', '', '', 'profile_1581791893.png', 'profile_background_1519924152.jpg', '', '', 01760607450, '', '', '', '', '', '', '', '', 1, '17-02-2020 10:37:54', '17-02-2020 11:47:54', '103.142.68.222', 0, 1, 'fixed_layout_hrsale', '', '', '0,1,2', 0, '2018-02-28 05:30:44'),
(6, 001, 1, 'Mostaim Billah', 'Murad', 'MostaimMurad', 'green.infotechbd@gmail.com', '$2y$12$QUfy8KNQNpxlXQrRRY3MrOpowk/NC1p/UpqVHx8vB/a3jvq68AbvC', '1985-04-22', 'Male', 0, 4, 3, 0, 11, 1, 2, 0, '', 0, 0, '2018-04-01', '', 'Single', '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Bandar, narayanganj', '', '', '', 'profile_1581766634.jpg', '', '', '', 01723221999, '', '', '', '', '', '', '', '', 1, '17-02-2020 12:07:39', '17-02-2020 11:38:28', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-15 11:31:02'),
(7, 002, 1, 'Rifat', 'Solaiman', 'RifatSolaiman', 'invisiblerifat@gmail.com', '$2y$12$ZJuB/6MPnPa7SIWMek3Ry.C7m6HA1HqN9.xHNeuhaUjdFk0gOCyrC', '1989-01-01', 'Male', 0, 4, 3, 0, 12, 1, 2, 0, '', 0, 0, '2018-04-01', '', 'Single', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Bandar, Narayanganj', '', '', '', '', '', '', '', 01811998241, '', '', '', '', '', '', '', '', 1, '16-02-2020 20:57:31', '16-02-2020 01:12:42', '103.142.68.222', 1, 1, '', '', '', '0,1,2', 0, '2020-02-15 01:18:31'),
(8, 003, 1, 'Sakib', 'Rahman', 'SakibRahman', 'sakibrahman.11.27@gmail.com', '$2y$12$M/pE1oIFCHppZsPygBRAgeYURPpYHN0hPdUEgG5XigOBYO9X5qNUK', '1997-08-07', 'Male', 0, 2, 4, 0, 9, 1, 2, '', '', 0, 0, '2020-02-01', '', 'Single', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No. Kadam Rasul Road, Nabiganj, Bandar, Narayanganj', '', '', '', '', '', '', '', 01534619961, '', '', '', '', '', '', '', '', 1, '16-02-2020 19:35:30', '', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-15 02:18:49'),
(9, 004, 1, 'Md. Towhid Raihan', 'Talukdar', 'TowhidRahman', 'towhid623@gmail.com', '$2y$12$nZes1tx6qqTKN2t1EuycJeLCUncyNzW8EEWuPZupcZ.gXr6kOkWc2', '1994-10-04', 'Male', 0, 2, 4, 0, 9, 1, 2, '', '', 0, 0, '2018-08-01', '', 'Married', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Bandar, narayanganj', '', '', '', 'profile_1581833544.jpg', '', '', '', 01631893580, '', '', '', '', '', '', '', '', 1, '17-02-2020 10:49:02', '', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-15 02:25:14'),
(10, 005, 1, 'Kazi', 'Sifat', 'KaziSifat', 'sifatovi007@gmail.com', '$2y$12$2ZN3wQ97vlJu5bqBCKJ9o.1xdOhGihbFk05Dg.Y4LfY6ot/hto3aa', '1993-08-01', 'Male', 0, 2, 4, 0, 9, 1, 2, '', '', 0, 0, '2019-03-18', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Bandar Narayanganj', '', '', '', 'profile_1581833190.jpg', '', '', '', 01677706308, '', '', '', '', '', '', '', '', 1, '17-02-2020 11:54:50', '', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-15 02:42:49'),
(11, 006, 1, 'Motasim Billah', 'Morshed', 'MotasiMorshed', 'gmt2motasim@gmail.com', '$2y$12$C7wg6PiQZESTXv8Rxhv9R.91SZL1nT4z0Vpqx1sgUp/VdAGVuh586', '1983-04-09', 'Male', 0, 1, 3, 0, 12, 1, 2, '', '', 0, 0, '2018-11-01', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Bandar, narayanganj', '', '', '', '', '', '', '', 01818133155, '', '', '', '', '', '', '', '', 1, '', '', '', 0, 0, '', '', '', 0, 0, '2020-02-15 04:51:26'),
(12, 007, 1, 'Nure Kamal', 'Mithu', 'NureKamal', 'splendidkamal@gmail.com', '$2y$12$3fP/SHF1JKBkQYNy41Wjbug0AgWzGt9v9PVo2mU9rDh84LD06vMKO', '1993-09-01', 'Male', 0, 2, 9, 0, 14, 1, 2, '', '', 0, 0, '2019-01-01', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Lakshmipur', '', '', '', '', '', '', '', 01814959293, '', '', '', '', '', '', '', '', 1, '17-02-2020 11:00:55', '16-02-2020 11:46:41', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-16 04:37:14'),
(13, 008, 1, 'Md', 'Wahid', 'MdWahid', 'mdwahid.eu@gmail.com', '$2y$12$q3LhcOuc9cp0EJSehcSeD.DMq6WhozW9nfyUnxWgaVOhKq8mUjbry', '1994-03-08', 'Male', 0, 2, 4, 0, 9, 1, 2, '', '', 0, 0, '2020-02-01', '', 'Single', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Narayanganj', '', '', '', 'profile_1581835380.jpg', '', '', '', 01689308776, '', '', '', '', '', '', '', '', 1, '17-02-2020 11:04:43', '16-02-2020 12:49:44', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-16 05:03:02'),
(14, 009, 1, 'Md. Saiful', 'Islam', 'Msaiful', 'msaiful@softifybd.com', '$2y$12$chRFA6bw.lrslGmmJgtgBu1ty59I4GfX5QkYtBmwlLL7BqjzG79Ma', '1994-05-30', 'Male', 0, 2, 4, 0, 9, 1, 2, '', '', 0, 0, '2018-11-15', '', 'Married', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Kalai, Jaypurhat', '', '', '', 'profile_1581916014.jpg', '', '', '', 01722182404, '', '', '', '', '', '', '', '', 1, '17-02-2020 11:02:03', '16-02-2020 12:38:51', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-16 05:24:27'),
(15, 010, 1, 'Md', 'AlAmin', 'MdAlamin', 'alamin.cse46@gmail.com', '$2y$12$KtqW0MIZ1PswnZR.RD74oOKQsVz0OK9me5rF.szwruxNzObwhqzbW', '1998-10-05', 'Male', 0, 2, 4, 0, 15, 1, 2, '', '', 0, 0, '2019-09-01', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Bandar', '', '', '', '', '', '', '', 01521435717, '', '', '', '', '', '', '', '', 1, '17-02-2020 11:08:05', '', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-16 06:23:44'),
(16, 011, 1, 'Pritom', 'Paul', 'PritomPaul', 'pritompal789@gmail.com', '$2y$12$s1yFCzzOjcVNIxPaKZVp5eNIh5/JDeVkgcHl1HX1pvch1XG3F4ZOW', '1995-10-25', 'Male', 0, 2, 4, 0, 9, 1, 2, '', '', 0, 0, '2019-09-01', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Lakshmipur', '', '', '', '', '', '', '', 01628160681, '', '', '', '', '', '', '', '', 1, '17-02-2020 11:01:07', '16-02-2020 13:45:30', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-16 06:37:42'),
(17, 012, 1, 'Md. Rakibul Islam', 'Refat', 'RakibulRefat', 'rakibulislam6619@gmail.com', '$2y$12$WWTWGr3TS7vmBFFFu0LSqeweRP9tIMkGOKxpLSpPEuNjLYQetCLiS', '1996-01-26', 'Male', 0, 2, 4, 0, 9, 1, 2, '', '', 0, 0, '2019-03-19', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Bandar, narayanganj', '', '', '', '', '', '', '', 01989882401, '', '', '', '', '', '', '', '', 1, '', '', '', 0, 0, '', '', '', '0,1,2', 0, '2020-02-16 06:54:16'),
(18, 013, 1, 'Jayadul', 'Islam', 'Jayadul', 'Jayadulsoftifybd@gmail.com', '$2y$12$vCgThUjZ/sPekl4DMpYWNOjRnkGShzOXwjE7eweqBA.Cd/KnTnSoO', '1995-06-27', 'Male', 0, 2, 4, 0, 15, 1, 2, '', '', 0, 0, '2018-05-22', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Bandar, Narayanganj', '', '', '', '', '', '', '', 01969155575, '', '', '', '', '', '', '', '', 1, '', '', '', 0, 0, '', '', '', '0,1,2', 0, '2020-02-16 07:03:23'),
(19, 014, 1, 'Alauddin', 'Khan', 'Alauddin', 'ak.softifybd@gmail.com', '$2y$12$cxGe7IZY.Rr9jJ4IXLxcPOTE86TyQRx0QxVwUiGDd2ZTLMHTI.m66', '1990-02-03', 'Male', 0, 2, 10, 0, 16, 1, 2, '', '', 0, 0, '2018-07-01', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Bandar, Narayanganj', '', '', '', '', '', '', '', 01674045202, '', '', '', '', '', '', '', '', 1, '17-02-2020 10:40:40', '17-02-2020 13:10:41', '103.142.68.150', 0, 0, '', '', '', '0,1,2', 0, '2020-02-16 07:20:01'),
(20, 015, 1, 'Mazharul', 'Huq', 'MazharulHuq', 'mazharulhuqankur@gmail.com', '$2y$12$Uj2yYee9twoL6keGxM3xteN4a6YlsNKvzTtR5Nj80Nbyh/pon7GJy', '1995-10-22', 'Male', 0, 2, 6, 0, 17, 1, 2, '', '', 0, 0, '2019-12-15', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Dhaka', '', '', '', '', '', '', '', 01986713577, '', '', '', '', '', '', '', '', 1, '', '', '', 0, 0, '', '', '', '0,1,2', 0, '2020-02-16 07:59:42'),
(21, 016, 1, 'Robiul', 'Islam', 'Robiul', 'robiul@softifybd.com', '$2y$12$z5MUea6qXuSMYmFvCXuLMO5sA2LjNsJ1bq3AF1RDGC14jA76QnP7a', '1995-08-13', 'Male', 0, 2, 7, 0, 18, 1, 2, '', '', 0, 0, '2019-07-01', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Lakshmipur', '', '', '', 'profile_1581914168.png', '', '', '', 01993148395, '', '', '', '', '', '', '', '', 1, '17-02-2020 10:38:51', '17-02-2020 11:40:14', '103.142.68.150', 0, 0, '', '', '', '0,1,2', 0, '2020-02-16 08:06:05'),
(22, 017, 1, 'Irfanul', 'Islam', 'Irfanul', 'irfaanul@gmail.com', '$2y$12$II/VicxS2UTQsjZWxtwzoeJjq/OSEXLqtjkkdprTFxphSn0sEtG6y', '1990-07-07', 'Male', 0, 2, 7, 0, 18, 1, 2, '', '', 0, 0, '2020-01-01', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Lakshmipur', '', '', '', '', '', '', '', 01742400408, '', '', '', '', '', '', '', '', 1, '', '', '', 0, 0, '', '', '', '0,1,2', 0, '2020-02-16 09:10:34'),
(23, 018, 1, 'Khaza', 'Md Rakib', 'MdRakib', 'rakib@softifybd.com', '$2y$12$obucthmtcTOz7jWUusJziOGHGqlQx2WdHcz5QVqu6p6qsaw2.osnq', '1994-12-28', 'Male', 0, 4, 5, 0, 19, 1, 2, 0, '', 0, 0, '2019-01-06', '', 'Married', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '123 Mokles Matbor Road (2nd Floor), Baganbari, Donia, Jatrabari, Dhaka - 1236', '', '', '', 'profile_1581913964.jpeg', '', '', '', 01915677699, '', '', '', '', '', '', '', '', 1, '17-02-2020 10:27:52', '17-02-2020 02:07:11', '103.142.68.222', 1, 0, '', '', '', '0,1,2', 0, '2020-02-16 10:28:38');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_ethnicity_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_ethnicity_type` (
  `ethnicity_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`ethnicity_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `xin_ethnicity_type`
		--
		INSERT INTO `xin_ethnicity_type` (`ethnicity_type_id`, `type`, `created_at`) VALUES
(1, 'Islam', '16-02-2020 12:47:43'),
(2, 'Hinduism', '16-02-2020 11:59:15'),
(3, 'Christianity', '16-02-2020 11:59:56');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_events`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_events` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` varchar(255) DEFAULT NULL,
  `event_title` varchar(255) NOT NULL,
  `event_date` varchar(255) NOT NULL,
  `event_time` varchar(255) NOT NULL,
  `event_note` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_expense_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_expense_type` (
  `expense_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_expense_type`
		--
		INSERT INTO `xin_expense_type` (`expense_type_id`, `company_id`, `name`, `status`, `created_at`) VALUES
(1, 1, 'Transport', 1, '22-03-2018 01:17:42'),
(2, 1, 'Rent Expense', 1, '22-03-2018 01:17:48');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_expenses`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_expenses` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(200) NOT NULL,
  `company_id` int(11) NOT NULL,
  `expense_type_id` int(200) NOT NULL,
  `billcopy_file` mediumtext NOT NULL,
  `amount` varchar(200) NOT NULL,
  `purchase_date` varchar(200) NOT NULL,
  `remarks` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `status_remarks` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_file_manager`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_file_manager` (
  `file_id` int(111) NOT NULL AUTO_INCREMENT,
  `user_id` int(111) NOT NULL,
  `department_id` int(111) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size` varchar(255) NOT NULL,
  `file_extension` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_file_manager_settings`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_file_manager_settings` (
  `setting_id` int(111) NOT NULL AUTO_INCREMENT,
  `allowed_extensions` mediumtext NOT NULL,
  `maximum_file_size` varchar(255) NOT NULL,
  `is_enable_all_files` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_file_manager_settings`
		--
		INSERT INTO `xin_file_manager_settings` (`setting_id`, `allowed_extensions`, `maximum_file_size`, `is_enable_all_files`, `updated_at`) VALUES
(1, 'gif,png,pdf,txt,doc,docx,.zip', 20, 'yes', '2020-02-17 12:03:30');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_bankcash`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_bankcash` (
  `bankcash_id` int(111) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) NOT NULL,
  `account_balance` varchar(255) NOT NULL,
  `account_opening_balance` varchar(200) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `branch_code` varchar(255) NOT NULL,
  `bank_branch` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`bankcash_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_deposit`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_deposit` (
  `deposit_id` int(111) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(111) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `deposit_date` varchar(255) NOT NULL,
  `category_id` int(111) NOT NULL,
  `payer_id` int(111) NOT NULL,
  `payment_method` int(111) NOT NULL,
  `deposit_reference` varchar(255) NOT NULL,
  `deposit_file` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`deposit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_expense`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_expense` (
  `expense_id` int(111) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(111) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `expense_date` varchar(255) NOT NULL,
  `category_id` int(111) NOT NULL,
  `payee_id` int(111) NOT NULL,
  `payment_method` int(111) NOT NULL,
  `expense_reference` varchar(255) NOT NULL,
  `expense_file` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_payees`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_payees` (
  `payee_id` int(11) NOT NULL AUTO_INCREMENT,
  `payee_name` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`payee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_payers`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_payers` (
  `payer_id` int(11) NOT NULL AUTO_INCREMENT,
  `payer_name` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`payer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_transaction`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `transaction_date` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `amount` float NOT NULL,
  `transaction_type` varchar(100) NOT NULL,
  `dr_cr` enum('dr','cr') NOT NULL,
  `transaction_cat_id` int(11) NOT NULL,
  `payer_payee_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `reference` varchar(100) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `invoice_type` varchar(100) DEFAULT NULL,
  `attachment_file` varchar(100) DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_transactions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_transactions` (
  `transaction_id` int(111) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(111) NOT NULL,
  `deposit_id` int(111) NOT NULL,
  `expense_id` int(111) NOT NULL,
  `transfer_id` int(111) NOT NULL,
  `transaction_type` varchar(255) NOT NULL,
  `total_amount` varchar(255) NOT NULL,
  `transaction_debit` varchar(255) NOT NULL,
  `transaction_credit` varchar(255) NOT NULL,
  `transaction_date` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_finance_transfer`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_finance_transfer` (
  `transfer_id` int(111) NOT NULL AUTO_INCREMENT,
  `from_account_id` int(111) NOT NULL,
  `to_account_id` int(111) NOT NULL,
  `transfer_date` varchar(255) NOT NULL,
  `transfer_amount` varchar(255) NOT NULL,
  `payment_method` varchar(111) NOT NULL,
  `transfer_reference` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`transfer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_goal_tracking`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_goal_tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `tracking_type_id` int(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `target_achiement` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `goal_progress` varchar(200) NOT NULL,
  `goal_status` int(11) NOT NULL DEFAULT 0,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`tracking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_goal_tracking_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_goal_tracking_type` (
  `tracking_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type_name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`tracking_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_goal_tracking_type`
		--
		INSERT INTO `xin_goal_tracking_type` (`tracking_type_id`, `company_id`, `type_name`, `created_at`) VALUES
(1, 1, 'Invoice Goal', '31-08-2018 01:29:44'),
(4, 1, 'Event Goal', '31-08-2018 01:29:47');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_holidays`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_holidays` (
  `holiday_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `event_name` varchar(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `is_publish` tinyint(1) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`holiday_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hourly_templates`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hourly_templates` (
  `hourly_rate_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `hourly_grade` varchar(255) NOT NULL,
  `hourly_rate` varchar(255) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`hourly_rate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_invoices`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_invoices` (
  `invoice_id` int(111) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) NOT NULL,
  `client_id` int(11) NOT NULL,
  `project_id` int(111) NOT NULL,
  `invoice_date` varchar(255) NOT NULL,
  `invoice_due_date` varchar(255) NOT NULL,
  `sub_total_amount` varchar(255) NOT NULL,
  `discount_type` varchar(11) NOT NULL,
  `discount_figure` varchar(255) NOT NULL,
  `total_tax` varchar(255) NOT NULL,
  `total_discount` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `invoice_note` mediumtext NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT 'null',
  `company_name` varchar(200) NOT NULL DEFAULT 'null',
  `client_profile` varchar(200) NOT NULL DEFAULT 'null',
  `email` varchar(200) NOT NULL DEFAULT 'null',
  `contact_number` varchar(200) NOT NULL DEFAULT 'null',
  `website_url` varchar(200) NOT NULL DEFAULT 'null',
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(200) NOT NULL DEFAULT 'null',
  `state` varchar(200) NOT NULL DEFAULT 'null',
  `zipcode` varchar(200) NOT NULL DEFAULT 'null',
  `countryid` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`invoice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_invoices_items`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_invoices_items` (
  `invoice_item_id` int(111) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(111) NOT NULL,
  `project_id` int(111) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_tax_type` varchar(255) NOT NULL,
  `item_tax_rate` varchar(255) NOT NULL,
  `item_qty` varchar(255) NOT NULL,
  `item_unit_price` varchar(255) NOT NULL,
  `item_sub_total` varchar(255) NOT NULL,
  `sub_total_amount` varchar(255) NOT NULL,
  `total_tax` varchar(255) NOT NULL,
  `discount_type` int(11) NOT NULL,
  `discount_figure` varchar(255) NOT NULL,
  `total_discount` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`invoice_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_module_attributes`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_module_attributes` (
  `custom_field_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `attribute_label` varchar(255) NOT NULL,
  `attribute_type` varchar(255) NOT NULL,
  `validation` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`custom_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_module_attributes_select_value`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_module_attributes_select_value` (
  `attributes_select_value_id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_field_id` int(11) NOT NULL,
  `select_label` varchar(255) NOT NULL,
  PRIMARY KEY (`attributes_select_value_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_module_attributes_values`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_module_attributes_values` (
  `attributes_value_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module_attributes_id` int(11) NOT NULL,
  `attribute_value` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`attributes_value_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_quotes`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_quotes` (
  `quote_id` int(111) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(255) NOT NULL,
  `project_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `quote_date` varchar(255) NOT NULL,
  `quote_due_date` varchar(255) NOT NULL,
  `client_id` int(11) NOT NULL,
  `sub_total_amount` varchar(255) NOT NULL,
  `discount_type` varchar(11) NOT NULL,
  `discount_figure` varchar(255) NOT NULL,
  `total_tax` varchar(255) NOT NULL,
  `tax_type` varchar(100) NOT NULL,
  `tax_figure` varchar(255) NOT NULL,
  `total_discount` varchar(255) NOT NULL,
  `quote_type` varchar(100) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `quote_note` mediumtext NOT NULL,
  `name` varchar(200) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `client_profile` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact_number` varchar(200) NOT NULL,
  `website_url` varchar(200) NOT NULL,
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `zipcode` varchar(200) NOT NULL,
  `countryid` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`quote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_hrsale_quotes_items`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_hrsale_quotes_items` (
  `quote_item_id` int(111) NOT NULL AUTO_INCREMENT,
  `quote_id` int(111) NOT NULL,
  `project_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_tax_type` varchar(255) NOT NULL,
  `item_tax_rate` varchar(255) NOT NULL,
  `item_qty` varchar(255) NOT NULL,
  `item_unit_price` varchar(255) NOT NULL,
  `item_sub_total` varchar(255) NOT NULL,
  `sub_total_amount` varchar(255) NOT NULL,
  `total_tax` varchar(255) NOT NULL,
  `tax_type` int(11) NOT NULL,
  `tax_figure` varchar(200) NOT NULL,
  `discount_type` int(11) NOT NULL,
  `discount_figure` varchar(255) NOT NULL,
  `total_discount` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`quote_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_income_categories`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_income_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_income_categories`
		--
		INSERT INTO `xin_income_categories` (`category_id`, `name`, `status`, `created_at`) VALUES
(4, 'Interest Income', 1, '25-03-2018 09:36:53'),
(5, 'Part Time Work', 1, '25-03-2018 09:37:13'),
(7, 'Salary Income', 1, '17-02-2020 12:21:18'),
(8, 'Bonus Income', 1, '17-02-2020 12:21:50'),
(9, 'Award Income', 1, '17-02-2020 12:23:13');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_applications`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_applications` (
  `application_id` int(111) NOT NULL AUTO_INCREMENT,
  `job_id` int(111) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `user_id` int(111) NOT NULL,
  `message` mediumtext NOT NULL,
  `job_resume` mediumtext NOT NULL,
  `application_status` int(11) NOT NULL DEFAULT 0,
  `application_remarks` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_categories`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `category_url` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_job_categories`
		--
		INSERT INTO `xin_job_categories` (`category_id`, `category_name`, `category_url`, `created_at`) VALUES
(1, 'PHP', 'q7VJh5xWwr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(2, 'Android', 'q7VJh5xWwr56ycN0m34Aou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(3, 'WordPress', 'q2327VJh5xWwr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(4, 'Design', '0oplfq7VJh5xWwr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(5, 'Developer', '34e6zyr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(6, 'iOS', 'l1BbMd6H2D3rkFnjU9LgCq7VJh5xWwr56ycN0mAou4266iOY8', '2018-04-15'),
(7, 'Mobile', 'l1BbMd6H2D3rkFnjU9LgCH2D3rkFnjU9BbMd6H2D3r', '2018-04-15'),
(8, 'MySQL', '2D3rkFnjU9LgCq7VJh5xWwl1BbMd6H2D3rkFnjU9LgCq7VJh5xWwr56ycN0mAou4266iOY8', '2018-04-15'),
(9, 'JavaScript', 'gCq7VJh5xWwl1BbMd6H2D3rkFnjU9LgCq7VJh5xWwl1BbMd6H2D3rkFnjU9LgCq7VJh5xWwr56ycN0mAou4266iOY8', '2018-04-15'),
(10, 'Software', 'zyr56ycN0mAou42634e6zyr56ycN0mAou4266iOY8l1BbMd6H2D3rkFnjU9LgC', '2018-04-15'),
(11, 'Website Design', '6iOY8l1BbMd6H2D3rkFnjU9LgCzyr56ycN0mAou42634e6zyr56ycN0mAou426', '2018-04-15'),
(12, 'Programming', 'jU9LgCzyr56ycN0mAou4266iOY8l1BbMd6H2D3rkFn34e6zyr56ycN0mAou426', '2018-04-15'),
(13, 'SEO', 'cN0mAou4266iOY8l1Bq2327VJh5xWwr56ybMd6H2D3rkFnjU9LgC', '2018-04-15'),
(14, 'Java', 'VJh5xWwr56ybMd6H2DcN0mAou4266iOY8l1Bq23273rkFnjU9LgC', '2018-04-15'),
(15, 'CSS', 'VJh5xWwr56ybMd6H2Dsdfkkj58234ksklEr6ybMd6H2D', '2018-04-15'),
(16, 'HTML5', '0349324k0434r23ksodfkpsodkfposakfkpww3MsH2Dei30ks', '2018-04-15'),
(17, 'Web Development', 'sdfj0rkskfskdfj329FLE34LFMsH2Dei30ks0349324k0434', '2018-04-15'),
(18, 'Web Design', 'MsH2Deiee30ks0349324k0434klEr6ybMd6234b5ksddif0k33', '2018-04-15'),
(19, 'eCommerce', 'klEr6ybMd6234bMsH2Dei30ks0349324k04345ksddif0k33', '2018-04-15'),
(20, 'Design', '234bMsklEr6ybMd6H2Dssdk5yy98ooVJh5xWwr56y435gghhole93lfkkj58', '2018-04-15'),
(21, 'Logo Design', 'k5yy98ooVJh5xWw45456y435gghhole93lfkkj58234bMsklEr6ybMd6H2D', '2018-04-15'),
(22, 'Graphic Design', 'k5yy98ooVJh5xWwr56y435gghhole93lfkkj58234bMsklEr6ybMd6H2D', '2018-04-15'),
(23, 'Video', 'k98ooVJh5xWwr56y435gghhole93lfkkj58234bMsklEr6ybMd6H2D', '2018-04-15'),
(24, 'Animation', 'ole93lfkkj58234k98ooVJh5xWwr56ybMsklEr6ybMd6H2D', '2018-04-15'),
(25, 'Adobe Photoshop', 'd6H2Dsdfkkj58234k98ooVJh5xWwr56ybMsklEr6ybMd6H2D', '2018-04-15'),
(26, 'Illustration', 'xWwr56ybMd6H2DcN0mA3405kfVJh5ou4266iOY8l1Bq23273rkFnjU9LgC', '2018-04-15'),
(27, 'Art', '3405kfVJh5ou4266iOY8l1Bq23273rk3ok3xWwr56ybMd6H2DcN0mAFnjU9LgC', '2018-04-15'),
(28, '3D', 'Md6H2DcN0mAFnjU9LfVJh5ou4266iOY8l1Bq23273rk3ok3xWwr56ybgC', '2018-04-15'),
(29, 'Adobe Illustrator', '5ou4266iOY8l1Bq23273rkMd6H2DcN0mAFnjU9LfVJh3ok3xWwr56ybgCww', '2018-04-15'),
(30, 'Drawing', '6iOY8l1Bq23273rk0234KILR23492034ksfpd456yslfdsf5ou426', '2018-04-15'),
(31, 'Web Design', '3l34l432fo232l3223DhssdfRKLl5434lsdfl3l3sfs3lllblp23D', '2018-04-15'),
(32, 'Cartoon', 'sdfowerewl567lflsdfl3l3sf3l34l432fo232l3223Dhs3lllblp23D', '2018-04-15'),
(33, 'Graphics', '3232l32hsfo23lllblp23D9LfVJkfo394s5ou42at5sd20cNsolof3llsblp23DcN', '2018-04-15'),
(34, 'Fashion Design', '9LfVJkfo394s5ou42at5sd203232l32hsfo23lllblp23DcNsolof3llsblp23DcN', '2018-04-15'),
(35, 'WordPress', 'hsfo23lllblp23DcNsolof3llsblp23DcN9LfVJkfo394s5ou42', '2018-04-15'),
(36, 'Editing', 'lof3llsblp23DcN9LfVJhsfo23lllblp23DcNsokfo394s5ou42', '2018-04-15'),
(37, 'Writing', 'blp23DcNsokfo394slof3llsblp23DcN9LfVJh5ou42', '2018-04-15'),
(38, 'T-Shirt Design', '9LfVJh5ou42blp23DcNsdf329LfVJh5ou42bsokjfwpoek0mAFnjU', '2018-04-15'),
(39, 'Display Advertising', '9LfVJh5ou42bsokjfwpoek9LfVJh5ou42blp23DcN0mAFnjU', '2018-04-15'),
(40, 'Email Marketing', 'DcN0mAFnjU9LfVJh5ou42bs66iOY8l1Bq23273rk3ok3xWwr56yMd6H2gC', '2018-04-15'),
(41, 'Lead Generation', '66iOY8l1Bq23273rk3ok3xWwr56yMd6H2DcN0mAFnjU9LfVJh5ou42bgC', '2018-04-15'),
(42, 'Market & Customer Research', 'Aou42Eou42iOY800Ke3klAou42066iOY800fklAou42', '2018-04-15'),
(43, 'Marketing Strategy', 'EKe3000fklAou4266iOY8l1kkadwlsdfk20323rlsKh4KadlLL', '2018-04-15'),
(44, 'Public Relations', 'l1kkadwlsdfk20323rlsKh4KadlLLEKe3000fklAou4266iOY8', '2018-04-15'),
(45, 'Telemarketing & Telesales', 'fklAou4266iOY8l1kkadwlsfBf329k3249owe923ksd324odLL2DcN0m', '2018-04-15'),
(46, 'Other - Sales & Marketing', 'Bf329k3249owe923ksd324odfklAou4266iOY8l1kkadwlLL2DcN0m', '2018-04-15'),
(47, 'SEM - Search Engine Marketing', 'Aou4266iOY8l1Bf329k3249owe923ksdkkadwlLL2DcN0m', '2018-04-15'),
(48, 'SEO - Search Engine Optimization', 'rk0234KILR23492034ksfpd456y6iOY8l1Bq23273slfdsf5ou426', '2018-04-15'),
(49, 'SMM - Social Media Marketing', '2DcN0mAou4266iOY8l1BVJh5xWwr56ybMd6Hq23273rkFnjU9LgC', '2018-04-15');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_interviews`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_interviews` (
  `job_interview_id` int(111) NOT NULL AUTO_INCREMENT,
  `job_id` int(111) NOT NULL,
  `interviewers_id` varchar(255) NOT NULL,
  `interview_place` varchar(255) NOT NULL,
  `interview_date` varchar(255) NOT NULL,
  `interview_time` varchar(255) NOT NULL,
  `interviewees_id` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`job_interview_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_pages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `page_details` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_job_pages`
		--
		INSERT INTO `xin_job_pages` (`page_id`, `page_title`, `page_url`, `page_details`, `created_at`) VALUES
(1, 'About Us', 'xl9wkRy7tqOehBo6YCDjFG2JTucpKI4gMNsn8Zdf', 'About Ussss', '2018-04-15'),
(2, 'Communications', '5uk4EUc3V9FYTbBQz7PWgKM6qCajfAipvhOJnZHl', 'Communications', '2018-04-15'),
(3, 'Lending Licenses', '5r6OCsUoHQFiRwI17W0eT38jbvpxEGuLhzgmt9lZ', 'Lending Licenses', '2018-04-15'),
(4, 'Terms of Service', 'QrfbMOUWpdYNxjLFz8G1m6t3wi0X2RKEZVC9ySka', 'Terms of Service', '2018-04-15'),
(5, 'Privacy Policy', 'rjHKhmsNezT2OJBAoQq0yU1tL5F34MCwgIiZEc7x', 'Privacy Policy', '2018-04-15'),
(6, 'Support', 'gZbBVMxnfzYLlC2AOk609Q7yWpaSjmJHuRXosr58', 'Support', '2018-04-15'),
(7, 'How It Works', 'l1BbMd6H2D3rkFnjU9LgCH2D3rkFnjU9BbMd6H2D3r', 'How It Works', '2018-04-15'),
(8, 'Disclaimers', 'CTbzS9IrWkNU7VM3HGZYjp6iwmfyXDOQgtsP8FEc', 'Disclaimers', '2018-04-15');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_job_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_job_type` (
  `job_type_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `type_url` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`job_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_job_type`
		--
		INSERT INTO `xin_job_type` (`job_type_id`, `company_id`, `type`, `type_url`, `created_at`) VALUES
(1, 1, 'Full Time', 'full-time', '22-03-2018 02:18:48'),
(2, 1, 'Part Time', 'part-time', '16-04-2018 06:29:45'),
(3, 1, 'Internship', 'internship', '16-04-2018 06:30:06'),
(4, 1, 'Freelance', 'freelance', '16-04-2018 06:30:21'),
(5, 1, 'Remotely', 'VTSh07Wjatq1Ex2Ac9sNuyzZmiIODlvwRenfPMUY', '16-02-2020 01:01:09');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_jobs`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_jobs` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `employer_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `designation_id` int(111) NOT NULL,
  `job_url` varchar(255) NOT NULL,
  `job_type` int(225) NOT NULL,
  `category_url` varchar(255) NOT NULL,
  `is_featured` int(11) NOT NULL,
  `type_url` varchar(255) NOT NULL,
  `job_vacancy` int(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `minimum_experience` varchar(255) NOT NULL,
  `date_of_closing` varchar(200) NOT NULL,
  `short_description` mediumtext NOT NULL,
  `long_description` mediumtext NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_kpi_incidental`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_kpi_incidental` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `incidental_kpi` text NOT NULL,
  `targeted_date` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `quarter` int(11) NOT NULL,
  `result` varchar(200) NOT NULL,
  `feedback` text NOT NULL,
  `year_created` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_kpi_maingoals`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_kpi_maingoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `main_kpi` varchar(255) NOT NULL,
  `year_created` varchar(200) NOT NULL,
  `status` varchar(100) NOT NULL,
  `approve_status` varchar(100) NOT NULL,
  `q1` varchar(100) NOT NULL,
  `q2` varchar(100) NOT NULL,
  `q3` varchar(100) NOT NULL,
  `q4` varchar(100) NOT NULL,
  `feedback` varchar(255) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_kpi_variable`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_kpi_variable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `variable_kpi` varchar(200) NOT NULL,
  `targeted_date` varchar(200) NOT NULL,
  `result` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `approve_status` varchar(200) NOT NULL,
  `feedback` text NOT NULL,
  `quarter` varchar(200) NOT NULL,
  `year_created` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_languages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_languages` (
  `language_id` int(111) NOT NULL AUTO_INCREMENT,
  `language_name` varchar(255) NOT NULL,
  `language_code` varchar(255) NOT NULL,
  `language_flag` varchar(255) NOT NULL,
  `is_active` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_languages`
		--
		INSERT INTO `xin_languages` (`language_id`, `language_name`, `language_code`, `language_flag`, `is_active`, `created_at`) VALUES
(1, 'English', 'english', 'language_flag_1520564355.gif', 1, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_leads`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_leads` (
  `client_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `client_username` varchar(255) NOT NULL,
  `client_password` varchar(255) NOT NULL,
  `client_profile` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `is_changed` int(11) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `website_url` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(111) NOT NULL,
  `is_active` int(11) NOT NULL,
  `last_logout_date` varchar(255) NOT NULL,
  `last_login_date` varchar(255) NOT NULL,
  `last_login_ip` varchar(255) NOT NULL,
  `is_logged_in` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_leads`
		--
		INSERT INTO `xin_leads` (`client_id`, `name`, `email`, `client_username`, `client_password`, `client_profile`, `contact_number`, `company_name`, `is_changed`, `gender`, `website_url`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `is_active`, `last_logout_date`, `last_login_date`, `last_login_ip`, `is_logged_in`, `created_at`) VALUES
(1, 'Shourav', 'robiul.techman@gmail.com', '', '$2y$12$fKvt73.42B.uwyEwTEbRsubE3jBnRfx79IeY6dnNxfXsVC05UazSa', '', 01844991699, 'Search IT', 0, '', '', 'Sreemangal', 'Sreemangal', 'Sreemangal', 'Sylhet', '', 18, 1, '', '', '', 0, '2020-02-16 14:14:38');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_leave_applications`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_leave_applications` (
  `leave_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(222) NOT NULL,
  `department_id` int(11) NOT NULL,
  `leave_type_id` int(222) NOT NULL,
  `from_date` varchar(200) NOT NULL,
  `to_date` varchar(200) NOT NULL,
  `applied_on` varchar(200) NOT NULL,
  `reason` mediumtext NOT NULL,
  `remarks` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `is_half_day` tinyint(1) DEFAULT NULL,
  `is_notify` int(11) NOT NULL,
  `leave_attachment` varchar(255) DEFAULT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_leave_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_leave_type` (
  `leave_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type_name` varchar(200) NOT NULL,
  `days_per_year` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_leave_type`
		--
		INSERT INTO `xin_leave_type` (`leave_type_id`, `company_id`, `type_name`, `days_per_year`, `status`, `created_at`) VALUES
(1, 1, 'Casual Leave', 10, 1, '19-03-2018 07:52:20'),
(2, 1, 'Sick Leave', 5, 1, '19-03-2018 07:52:30');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_make_payment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_make_payment` (
  `make_payment_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `department_id` int(111) NOT NULL,
  `company_id` int(111) NOT NULL,
  `location_id` int(111) NOT NULL,
  `designation_id` int(111) NOT NULL,
  `payment_date` varchar(200) NOT NULL,
  `basic_salary` varchar(255) NOT NULL,
  `payment_amount` varchar(255) NOT NULL,
  `gross_salary` varchar(255) NOT NULL,
  `total_allowances` varchar(255) NOT NULL,
  `total_deductions` varchar(255) NOT NULL,
  `net_salary` varchar(255) NOT NULL,
  `house_rent_allowance` varchar(255) NOT NULL,
  `medical_allowance` varchar(255) NOT NULL,
  `travelling_allowance` varchar(255) NOT NULL,
  `dearness_allowance` varchar(255) NOT NULL,
  `provident_fund` varchar(255) NOT NULL,
  `tax_deduction` varchar(255) NOT NULL,
  `security_deposit` varchar(255) NOT NULL,
  `overtime_rate` varchar(255) NOT NULL,
  `is_advance_salary_deduct` int(11) NOT NULL,
  `advance_salary_amount` varchar(255) NOT NULL,
  `is_payment` tinyint(1) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `hourly_rate` varchar(255) NOT NULL,
  `total_hours_work` varchar(255) NOT NULL,
  `comments` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`make_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_meetings`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_meetings` (
  `meeting_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` varchar(255) DEFAULT NULL,
  `meeting_title` varchar(255) NOT NULL,
  `meeting_date` varchar(255) NOT NULL,
  `meeting_time` varchar(255) NOT NULL,
  `meeting_room` varchar(255) NOT NULL,
  `meeting_note` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_office_location`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_office_location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(111) NOT NULL,
  `location_head` int(111) NOT NULL,
  `location_manager` int(111) NOT NULL,
  `location_name` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `address_1` mediumtext NOT NULL,
  `address_2` mediumtext NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(111) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_office_location`
		--
		INSERT INTO `xin_office_location` (`location_id`, `company_id`, `location_head`, `location_manager`, `location_name`, `email`, `phone`, `fax`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `added_by`, `created_at`, `status`) VALUES
(2, 1, 6, 0, 'Head Office', 'softifybd@gmail.com', 01730797262, '', 'Hazi Motaleb Plaza, S.S. Shah Road', 'Bandar', 'Narayanganj', 'Dhaka', 1410, 18, 1, '15-02-2020', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_office_shift`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_office_shift` (
  `office_shift_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `shift_name` varchar(255) NOT NULL,
  `default_shift` int(111) NOT NULL,
  `monday_in_time` varchar(222) NOT NULL,
  `monday_out_time` varchar(222) NOT NULL,
  `tuesday_in_time` varchar(222) NOT NULL,
  `tuesday_out_time` varchar(222) NOT NULL,
  `wednesday_in_time` varchar(222) NOT NULL,
  `wednesday_out_time` varchar(222) NOT NULL,
  `thursday_in_time` varchar(222) NOT NULL,
  `thursday_out_time` varchar(222) NOT NULL,
  `friday_in_time` varchar(222) NOT NULL,
  `friday_out_time` varchar(222) NOT NULL,
  `saturday_in_time` varchar(222) NOT NULL,
  `saturday_out_time` varchar(222) NOT NULL,
  `sunday_in_time` varchar(222) NOT NULL,
  `sunday_out_time` varchar(222) NOT NULL,
  `created_at` varchar(222) NOT NULL,
  PRIMARY KEY (`office_shift_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_office_shift`
		--
		INSERT INTO `xin_office_shift` (`office_shift_id`, `company_id`, `shift_name`, `default_shift`, `monday_in_time`, `monday_out_time`, `tuesday_in_time`, `tuesday_out_time`, `wednesday_in_time`, `wednesday_out_time`, `thursday_in_time`, `thursday_out_time`, `friday_in_time`, `friday_out_time`, `saturday_in_time`, `saturday_out_time`, `sunday_in_time`, `sunday_out_time`, `created_at`) VALUES
(1, 1, 'Regular Shift', 1, '10:00', '19:00', '10:00', '19:00', '10:59', '19:00', '10:00', '19:00', '10:00', '19:00', '10:00', '19:00', '10:00', '19:00', '2018-02-28');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_payment_method`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_payment_method` (
  `payment_method_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `method_name` varchar(255) NOT NULL,
  `payment_percentage` varchar(200) DEFAULT NULL,
  `account_number` varchar(200) DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`payment_method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_payment_method`
		--
		INSERT INTO `xin_payment_method` (`payment_method_id`, `company_id`, `method_name`, `payment_percentage`, `account_number`, `created_at`) VALUES
(1, 1, 'Cash', 30, '', '23-04-2018 05:13:52'),
(2, 1, 'Paypal', 40, 1, '12-08-2018 02:18:50'),
(3, 1, 'Bank', 30, 1231232, '12-08-2018 02:18:57');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_payroll_custom_fields`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_payroll_custom_fields` (
  `payroll_custom_id` int(11) NOT NULL AUTO_INCREMENT,
  `allow_custom_1` varchar(255) NOT NULL,
  `is_active_allow_1` int(11) NOT NULL,
  `allow_custom_2` varchar(255) NOT NULL,
  `is_active_allow_2` int(11) NOT NULL,
  `allow_custom_3` varchar(255) NOT NULL,
  `is_active_allow_3` int(11) NOT NULL,
  `allow_custom_4` varchar(255) NOT NULL,
  `is_active_allow_4` int(11) NOT NULL,
  `allow_custom_5` varchar(255) NOT NULL,
  `is_active_allow_5` int(111) NOT NULL,
  `deduct_custom_1` varchar(255) NOT NULL,
  `is_active_deduct_1` int(11) NOT NULL,
  `deduct_custom_2` varchar(255) NOT NULL,
  `is_active_deduct_2` int(11) NOT NULL,
  `deduct_custom_3` varchar(255) NOT NULL,
  `is_active_deduct_3` int(11) NOT NULL,
  `deduct_custom_4` varchar(255) NOT NULL,
  `is_active_deduct_4` int(11) NOT NULL,
  `deduct_custom_5` varchar(255) NOT NULL,
  `is_active_deduct_5` int(11) NOT NULL,
  PRIMARY KEY (`payroll_custom_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_performance_appraisal`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_performance_appraisal` (
  `performance_appraisal_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `appraisal_year_month` varchar(255) NOT NULL,
  `customer_experience` int(111) NOT NULL,
  `marketing` int(111) NOT NULL,
  `management` int(111) NOT NULL,
  `administration` int(111) NOT NULL,
  `presentation_skill` int(111) NOT NULL,
  `quality_of_work` int(111) NOT NULL,
  `efficiency` int(111) NOT NULL,
  `integrity` int(111) NOT NULL,
  `professionalism` int(111) NOT NULL,
  `team_work` int(111) NOT NULL,
  `critical_thinking` int(111) NOT NULL,
  `conflict_management` int(111) NOT NULL,
  `attendance` int(111) NOT NULL,
  `ability_to_meet_deadline` int(111) NOT NULL,
  `remarks` mediumtext NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`performance_appraisal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_performance_appraisal_options`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_performance_appraisal_options` (
  `performance_appraisal_options_id` int(11) NOT NULL AUTO_INCREMENT,
  `appraisal_id` int(11) NOT NULL,
  `appraisal_type` varchar(200) NOT NULL,
  `appraisal_option_id` int(11) NOT NULL,
  `appraisal_option_value` int(11) NOT NULL,
  PRIMARY KEY (`performance_appraisal_options_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_performance_indicator`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_performance_indicator` (
  `performance_indicator_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `designation_id` int(111) NOT NULL,
  `customer_experience` int(111) NOT NULL,
  `marketing` int(111) NOT NULL,
  `management` int(111) NOT NULL,
  `administration` int(111) NOT NULL,
  `presentation_skill` int(111) NOT NULL,
  `quality_of_work` int(111) NOT NULL,
  `efficiency` int(111) NOT NULL,
  `integrity` int(111) NOT NULL,
  `professionalism` int(111) NOT NULL,
  `team_work` int(111) NOT NULL,
  `critical_thinking` int(111) NOT NULL,
  `conflict_management` int(111) NOT NULL,
  `attendance` int(111) NOT NULL,
  `ability_to_meet_deadline` int(111) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`performance_indicator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_performance_indicator_options`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_performance_indicator_options` (
  `performance_indicator_options_id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_id` int(11) NOT NULL,
  `indicator_type` varchar(200) NOT NULL,
  `indicator_option_id` int(11) NOT NULL,
  `indicator_option_value` int(11) NOT NULL,
  PRIMARY KEY (`performance_indicator_options_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_project_variations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_project_variations` (
  `variation_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `project_id` int(111) NOT NULL,
  `created_by` int(111) NOT NULL,
  `variation_name` varchar(255) NOT NULL,
  `variation_no` varchar(255) NOT NULL,
  `assigned_to` varchar(255) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `variation_hours` varchar(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `variation_status` int(5) NOT NULL,
  `client_approval` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`variation_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects` (
  `project_id` int(111) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `client_id` int(100) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `company_id` int(111) NOT NULL,
  `assigned_to` mediumtext NOT NULL,
  `priority` varchar(255) NOT NULL,
  `project_no` varchar(255) DEFAULT NULL,
  `budget_hours` varchar(255) DEFAULT NULL,
  `summary` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `added_by` int(111) NOT NULL,
  `project_progress` varchar(255) NOT NULL,
  `project_note` longtext NOT NULL,
  `status` tinyint(2) NOT NULL,
  `is_notify` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_projects`
		--
		INSERT INTO `xin_projects` (`project_id`, `title`, `client_id`, `start_date`, `end_date`, `company_id`, `assigned_to`, `priority`, `project_no`, `budget_hours`, `summary`, `description`, `added_by`, `project_progress`, `project_note`, `status`, `is_notify`, `created_at`) VALUES
(2, 'ISP Digital', 2, '2018-05-01', '2022-12-31', 1, '9,14', 2, '1H12Y30', 9994, 'Internet Service Providers have a special contribution to our country to keep pace with the developed world. But in order to provide this service, owners have to face a lot of complications to manage the business. Thinking about this complexity, we Softifybd Limited created ISP Management Software to make business management extremely easy and dynamic.', '&lt;p&gt;ISP Billing &amp; Management Software�&lt;/p&gt;', 6, 0, '', 1, 0, '15-02-2020'),
(3, 'SoftifyBD Website Design & Development', 2, '2020-02-16', '2020-02-29', 1, 12, 2, 'MUKU7L6', 104, 'website design & development', '&lt;p&gt;website design &amp; development&lt;/p&gt;', 6, 0, '', 1, 0, '16-02-2020'),
(4, 'Motion Graphics & Video Editing ', 2, '2020-02-16', '2020-02-29', 1, 12, 3, 'VCJCOYQ', 10, 'Video Editing ', '&lt;p&gt;Video Editing�&lt;/p&gt;', 6, 0, '', 0, 0, '16-02-2020'),
(6, 'ISP Digital Apps PSD Design', 2, '2020-02-20', '2020-02-25', 1, '8,19', 1, 'MFHA9SQ', 25, 'ISP Digital Apps PSD Design (Client Portal, Employee, BW Resellar, MAC Resellar)', '&lt;p&gt;ISP Digital Apps PSD Design (Client Portal, Employee, BW Resellar, Mac Resellar)&lt;/p&gt;', 6, 0, '', 0, 0, '16-02-2020'),
(7, 'SoftifyBD Brand Graphics  Design', 2, '2020-02-17', '2020-12-31', 1, 19, 3, 'CXBG3KI', 100, 'SoftifyBD ?? ???? ??? ??? ?????? PSD & Logo ?? ????????? ????', 'SoftifyBD ?? ???? ??? ??? ?????? PSD &amp;amp; Logo ?? ????????? ????&lt;br&gt;', 6, 0, '', 0, 0, '17-02-2020'),
(8, 'A1 Remidial Portfolio  Website', 3, '2020-02-14', '2020-02-18', 1, '15,18', 1, 'EPRJN9V', 20, 'A1 Remidial Portfolio  Website', '&lt;p&gt;A1 Remidial Portfolio� Website&lt;/p&gt;', 6, 70, '', 1, 0, '17-02-2020');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects_attachment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects_attachment` (
  `project_attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(200) NOT NULL,
  `upload_by` int(255) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_description` mediumtext NOT NULL,
  `attachment_file` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`project_attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_projects_attachment`
		--
		INSERT INTO `xin_projects_attachment` (`project_attachment_id`, `project_id`, `upload_by`, `file_title`, `file_description`, `attachment_file`, `created_at`) VALUES
(1, 6, 8, 'Proposed UX Designs', 'This file contains links of some sample apps.\njust copy the link and see the app.', 'project_1581860358.txt', '16-02-2020 07:39:18'),
(4, 7, 6, 'Softy Logo, Icon', 'Softy Logo, Icon', 'project_1581919731.zip', '17-02-2020 12:08:51');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects_bugs`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects_bugs` (
  `bug_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(111) NOT NULL,
  `user_id` int(200) NOT NULL,
  `attachment_file` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects_discussion`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects_discussion` (
  `discussion_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(111) NOT NULL,
  `user_id` int(200) NOT NULL,
  `client_id` int(11) NOT NULL,
  `attachment_file` varchar(255) NOT NULL,
  `message` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`discussion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_projects_discussion`
		--
		INSERT INTO `xin_projects_discussion` (`discussion_id`, `project_id`, `user_id`, `client_id`, `attachment_file`, `message`, `created_at`) VALUES
(1, 6, 8, 0, 'no_file', 'For viewing the Apps selected in Printerest CLICK on the link \n\nhttps://pin.it/oaj4omrliaoeo4\n', '16-02-2020 07:42:20'),
(2, 8, 6, 0, 'no_file', 'Hi', '17-02-2020 11:33:38');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_projects_timelogs`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_projects_timelogs` (
  `timelogs_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `total_hours` varchar(255) NOT NULL,
  `timelogs_memo` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`timelogs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_qualification_education_level`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_qualification_education_level` (
  `education_level_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`education_level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_qualification_education_level`
		--
		INSERT INTO `xin_qualification_education_level` (`education_level_id`, `company_id`, `name`, `created_at`) VALUES
(2, 0, 'SSC', '16-02-2020 12:42:20'),
(3, 0, 'HSC', '16-02-2020 12:43:24'),
(4, 0, 'Bachelor', '16-02-2020 12:43:51'),
(5, 0, 'Masters', '16-02-2020 05:55:58'),
(6, 0, 'Diploma', '16-02-2020 05:56:18');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_qualification_language`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_qualification_language` (
  `language_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_qualification_language`
		--
		INSERT INTO `xin_qualification_language` (`language_id`, `company_id`, `name`, `created_at`) VALUES
(1, 1, 'English', '09-05-2018 03:12:03'),
(2, 0, 'Bangla', '16-02-2020 12:44:13');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_qualification_skill`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_qualification_skill` (
  `skill_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`skill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_qualification_skill`
		--
		INSERT INTO `xin_qualification_skill` (`skill_id`, `company_id`, `name`, `created_at`) VALUES
(1, 1, 'jQuery', '09-05-2018 03:12:08'),
(2, 0, 'PHP', '16-02-2020 01:02:46'),
(3, 0, 'Android', '16-02-2020 01:02:59'),
(4, 0, 'WordPress', '16-02-2020 01:03:05'),
(5, 0, 'Design', '16-02-2020 01:03:36'),
(6, 0, 'iOS', '16-02-2020 01:03:46'),
(7, 0, 'MySQL', '16-02-2020 01:03:52'),
(8, 0, 'JavaScript', '16-02-2020 01:03:57'),
(9, 0, 'Website Design', '16-02-2020 01:04:03'),
(10, 0, 'Programming', '16-02-2020 01:04:08'),
(12, 0, 'Java', '16-02-2020 01:04:23'),
(13, 0, 'CSS', '16-02-2020 01:04:30'),
(14, 0, 'HTML5', '16-02-2020 01:04:37'),
(15, 0, 'Web Development', '16-02-2020 01:04:41'),
(16, 0, 'eCommerce', '16-02-2020 01:04:52'),
(17, 0, 'Logo Design', '16-02-2020 01:04:57'),
(18, 0, 'Graphic Design', '16-02-2020 01:05:02'),
(19, 0, 'Video Editing', '16-02-2020 01:05:27'),
(21, 0, 'Animation', '16-02-2020 01:05:33'),
(22, 0, 'Adobe Photoshop', '16-02-2020 01:05:49'),
(23, 0, 'Adobe Illustrator', '16-02-2020 01:05:54'),
(24, 0, 'Art', '16-02-2020 01:05:59'),
(25, 0, '3D', '16-02-2020 01:06:04'),
(26, 0, 'Drawing', '16-02-2020 01:06:25'),
(27, 0, 'Writing', '16-02-2020 01:06:45'),
(28, 0, 'T-Shirt Design', '16-02-2020 01:06:56'),
(29, 0, 'Advertising', '16-02-2020 01:07:05'),
(30, 0, 'Email Marketing', '16-02-2020 01:07:09'),
(31, 0, 'Lead Generation', '16-02-2020 01:07:15'),
(32, 0, 'Market Analysis', '16-02-2020 01:07:21'),
(33, 0, 'Marketing Strategy', '16-02-2020 01:07:25'),
(34, 0, 'Public Relations', '16-02-2020 01:07:30'),
(35, 0, 'Telemarketing & Telesales', '16-02-2020 01:07:36'),
(36, 0, 'Sales & Marketing', '16-02-2020 01:07:45'),
(37, 0, 'Search Engine Marketing', '16-02-2020 01:07:51'),
(38, 0, 'Search Engine Optimization', '16-02-2020 01:07:57'),
(39, 0, 'Social Media Marketing', '16-02-2020 01:08:02'),
(40, 0, 'MS Office', '16-02-2020 11:42:43'),
(41, 0, 'Digital Marketing', '16-02-2020 11:43:45'),
(42, 0, 'Technical Support', '16-02-2020 11:43:56'),
(43, 0, 'Client Relations', '16-02-2020 11:44:06'),
(44, 0, 'Negotiation', '16-02-2020 11:44:19'),
(45, 0, 'Administration', '16-02-2020 11:44:52'),
(46, 0, 'Creative Thinking', '16-02-2020 11:45:02'),
(47, 0, 'Business Communication', '16-02-2020 11:45:15'),
(48, 0, 'Problem Solving', '16-02-2020 11:45:25'),
(49, 0, 'Decision Making', '16-02-2020 11:45:39'),
(50, 0, 'Task Management', '16-02-2020 11:45:48'),
(51, 0, 'Event Management', '16-02-2020 11:45:56'),
(52, 0, 'Documentation', '16-02-2020 11:46:06'),
(53, 0, 'Policy Development', '16-02-2020 11:46:14'),
(54, 0, 'HR Management', '16-02-2020 11:46:28'),
(55, 0, 'Recruitment & Selection', '16-02-2020 11:46:38'),
(56, 0, 'Motivation & Leadership', '16-02-2020 11:46:47'),
(57, 0, 'Payroll Processing', '16-02-2020 11:46:56'),
(58, 0, 'Compensation & Benefits', '16-02-2020 11:47:11'),
(59, 0, 'Supervision', '16-02-2020 11:47:25'),
(60, 0, 'Performance Evaluation', '16-02-2020 11:47:34'),
(61, 0, 'Financial Statements', '16-02-2020 11:47:44'),
(62, 0, 'Budgeting & Cost Control', '16-02-2020 11:47:54'),
(63, 0, 'Controling', '16-02-2020 11:48:05');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_recruitment_pages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_recruitment_pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `page_details` mediumtext NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_recruitment_pages`
		--
		INSERT INTO `xin_recruitment_pages` (`page_id`, `page_title`, `page_details`, `status`, `created_at`) VALUES
(1, 'Pages', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(2, 'About Us', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(3, 'Career Services', 'Career Services', 1, ''),
(4, 'Success Stories', 'Success Stories', 1, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_recruitment_subpages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_recruitment_subpages` (
  `subpages_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `sub_page_title` varchar(255) NOT NULL,
  `sub_page_details` mediumtext NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`subpages_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_recruitment_subpages`
		--
		INSERT INTO `xin_recruitment_subpages` (`subpages_id`, `page_id`, `sub_page_title`, `sub_page_details`, `status`, `created_at`) VALUES
(1, 1, 'Sub Menu 1', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(2, 1, 'Sub Menu 2', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(3, 1, 'Sub Menu 3', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(4, 1, 'Sub Menu 4', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(5, 1, 'Sub Menu 5', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, ''),
(6, 1, 'Sub Menu 6', 'Nulla dignissim gravida\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ultricies dictum ex, nec ullamcorper orci luctus eget. Integer mauris arcu, pretium eget elit vel, posuere consectetur massa. Etiam non fermentum augue, vel posuere sapien. \n\nVivamus aliquet eros bibendum ipsum euismod, non interdum dui elementum. Morbi facilisis hendrerit nisi, a volutpat velit. Donec sed malesuada felis. Nulla facilisi. Vivamus a velit vel orci euismod maximus. Praesent ut blandit orci, eget suscipit lorem. Aenean dignissim, augue at porta suscipit, est enim euismod mi, a rhoncus mi lacus ac nibh. Ut pharetra ligula sed tortor congue, pellentesque ultricies augue tincidunt.', 1, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_allowances`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_allowances` (
  `allowance_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `is_allowance_taxable` int(11) NOT NULL,
  `allowance_title` varchar(200) DEFAULT NULL,
  `allowance_amount` varchar(200) DEFAULT NULL,
  `created_at` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`allowance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_salary_allowances`
		--
		INSERT INTO `xin_salary_allowances` (`allowance_id`, `employee_id`, `is_allowance_taxable`, `allowance_title`, `allowance_amount`, `created_at`) VALUES
(1, 1, 0, 'Cost of Living Allowance', 100, ''),
(2, 1, 0, 'Housing Allowance', 200, ''),
(3, 1, 0, 'Market Adjustment', 200, ''),
(4, 1, 0, 'Meal Allowance', 100, ''),
(5, 1, 0, 'Transportation Allowance', 200, '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_bank_allocation`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_bank_allocation` (
  `bank_allocation_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `pay_percent` varchar(200) NOT NULL,
  `acc_number` varchar(200) NOT NULL,
  PRIMARY KEY (`bank_allocation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_commissions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_commissions` (
  `salary_commissions_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `commission_title` varchar(200) DEFAULT NULL,
  `commission_amount` varchar(200) DEFAULT NULL,
  `created_at` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`salary_commissions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_loan_deductions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_loan_deductions` (
  `loan_deduction_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `loan_options` int(11) NOT NULL,
  `loan_deduction_title` varchar(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `monthly_installment` varchar(200) NOT NULL,
  `loan_time` varchar(200) NOT NULL,
  `loan_deduction_amount` varchar(200) NOT NULL,
  `total_paid` varchar(200) NOT NULL,
  `reason` text NOT NULL,
  `status` int(11) NOT NULL,
  `is_deducted_from_salary` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`loan_deduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_other_payments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_other_payments` (
  `other_payments_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `payments_title` varchar(200) DEFAULT NULL,
  `payments_amount` varchar(200) DEFAULT NULL,
  `created_at` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`other_payments_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_overtime`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_overtime` (
  `salary_overtime_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `overtime_type` varchar(200) NOT NULL,
  `no_of_days` varchar(100) NOT NULL DEFAULT '0',
  `overtime_hours` varchar(100) NOT NULL DEFAULT '0',
  `overtime_rate` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`salary_overtime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_allowances`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_allowances` (
  `payslip_allowances_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `allowance_title` varchar(200) NOT NULL,
  `allowance_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_allowances_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_commissions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_commissions` (
  `payslip_commissions_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `commission_title` varchar(200) NOT NULL,
  `commission_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_commissions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_loan`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_loan` (
  `payslip_loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `loan_title` varchar(200) NOT NULL,
  `loan_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_other_payments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_other_payments` (
  `payslip_other_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `payments_title` varchar(200) NOT NULL,
  `payments_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_other_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_overtime`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_overtime` (
  `payslip_overtime_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `overtime_title` varchar(200) NOT NULL,
  `overtime_salary_month` varchar(200) NOT NULL,
  `overtime_no_of_days` varchar(200) NOT NULL,
  `overtime_hours` varchar(200) NOT NULL,
  `overtime_rate` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_overtime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslip_statutory_deductions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslip_statutory_deductions` (
  `payslip_deduction_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `deduction_title` varchar(200) NOT NULL,
  `deduction_amount` varchar(200) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_deduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_payslips`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_payslips` (
  `payslip_id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_key` varchar(200) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `salary_month` varchar(200) NOT NULL,
  `wages_type` int(11) NOT NULL,
  `payslip_type` varchar(50) NOT NULL,
  `basic_salary` varchar(200) NOT NULL,
  `daily_wages` varchar(200) NOT NULL,
  `is_half_monthly_payroll` tinyint(1) NOT NULL,
  `hours_worked` varchar(50) NOT NULL DEFAULT '0',
  `total_allowances` varchar(200) NOT NULL,
  `total_commissions` varchar(200) NOT NULL,
  `total_statutory_deductions` varchar(200) NOT NULL,
  `total_other_payments` varchar(200) NOT NULL,
  `total_loan` varchar(200) NOT NULL,
  `total_overtime` varchar(200) NOT NULL,
  `statutory_deductions` varchar(200) NOT NULL,
  `net_salary` varchar(200) NOT NULL,
  `grand_net_salary` varchar(200) NOT NULL,
  `other_payment` varchar(200) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `pay_comments` mediumtext NOT NULL,
  `is_payment` int(11) NOT NULL,
  `year_to_date` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`payslip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_statutory_deductions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_statutory_deductions` (
  `statutory_deductions_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `statutory_options` int(11) NOT NULL,
  `deduction_title` varchar(200) DEFAULT NULL,
  `deduction_amount` varchar(200) DEFAULT NULL,
  `created_at` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`statutory_deductions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_salary_templates`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_salary_templates` (
  `salary_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `salary_grades` varchar(255) NOT NULL,
  `basic_salary` varchar(255) NOT NULL,
  `overtime_rate` varchar(255) NOT NULL,
  `house_rent_allowance` varchar(255) NOT NULL,
  `medical_allowance` varchar(255) NOT NULL,
  `travelling_allowance` varchar(255) NOT NULL,
  `dearness_allowance` varchar(255) NOT NULL,
  `security_deposit` varchar(255) NOT NULL,
  `provident_fund` varchar(255) NOT NULL,
  `tax_deduction` varchar(255) NOT NULL,
  `gross_salary` varchar(255) NOT NULL,
  `total_allowance` varchar(255) NOT NULL,
  `total_deduction` varchar(255) NOT NULL,
  `net_salary` varchar(255) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`salary_template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_salary_templates`
		--
		INSERT INTO `xin_salary_templates` (`salary_template_id`, `company_id`, `salary_grades`, `basic_salary`, `overtime_rate`, `house_rent_allowance`, `medical_allowance`, `travelling_allowance`, `dearness_allowance`, `security_deposit`, `provident_fund`, `tax_deduction`, `gross_salary`, `total_allowance`, `total_deduction`, `net_salary`, `added_by`, `created_at`) VALUES
(1, 1, 'Monthly', 2500, '', 50, 60, 70, 80, 40, 20, 30, 2760, 260, 90, 2670, 1, '22-03-2018 01:40:06');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_security_level`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_security_level` (
  `type_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_security_level`
		--
		INSERT INTO `xin_security_level` (`type_id`, `name`, `created_at`) VALUES
(1, 'SSL', '16-02-2020 01:09:36');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_sub_departments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_sub_departments` (
  `sub_department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `department_name` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`sub_department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_sub_departments`
		--
		INSERT INTO `xin_sub_departments` (`sub_department_id`, `department_id`, `department_name`, `created_at`) VALUES
(8, 1, 'Manager', '2019-02-15 00:22:13'),
(9, 1, 'Lead Manager', '2019-02-15 00:22:21'),
(10, 2, 'Accountant', '2019-02-15 00:22:26');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_support_ticket_files`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_support_ticket_files` (
  `ticket_file_id` int(111) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(111) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `ticket_files` varchar(255) NOT NULL,
  `file_size` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`ticket_file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_support_tickets`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_support_tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `ticket_code` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `ticket_priority` varchar(255) NOT NULL,
  `department_id` int(111) NOT NULL,
  `assigned_to` mediumtext NOT NULL,
  `message` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `ticket_remarks` mediumtext NOT NULL,
  `ticket_status` varchar(200) NOT NULL,
  `ticket_note` mediumtext NOT NULL,
  `is_notify` int(11) NOT NULL,
  `ticket_image` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_support_tickets_employees`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_support_tickets_employees` (
  `tickets_employees_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `is_notify` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`tickets_employees_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_system_setting`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_system_setting` (
  `setting_id` int(111) NOT NULL AUTO_INCREMENT,
  `application_name` varchar(255) NOT NULL,
  `default_currency` varchar(255) NOT NULL,
  `default_currency_id` int(11) NOT NULL,
  `default_currency_symbol` varchar(255) NOT NULL,
  `show_currency` varchar(255) NOT NULL,
  `currency_position` varchar(255) NOT NULL,
  `notification_position` varchar(255) NOT NULL,
  `notification_close_btn` varchar(255) NOT NULL,
  `notification_bar` varchar(255) NOT NULL,
  `enable_registration` varchar(255) NOT NULL,
  `login_with` varchar(255) NOT NULL,
  `date_format_xi` varchar(255) NOT NULL,
  `employee_manage_own_contact` varchar(255) NOT NULL,
  `employee_manage_own_profile` varchar(255) NOT NULL,
  `employee_manage_own_qualification` varchar(255) NOT NULL,
  `employee_manage_own_work_experience` varchar(255) NOT NULL,
  `employee_manage_own_document` varchar(255) NOT NULL,
  `employee_manage_own_picture` varchar(255) NOT NULL,
  `employee_manage_own_social` varchar(255) NOT NULL,
  `employee_manage_own_bank_account` varchar(255) NOT NULL,
  `enable_attendance` varchar(255) NOT NULL,
  `enable_clock_in_btn` varchar(255) NOT NULL,
  `enable_email_notification` varchar(255) NOT NULL,
  `payroll_include_day_summary` varchar(255) NOT NULL,
  `payroll_include_hour_summary` varchar(255) NOT NULL,
  `payroll_include_leave_summary` varchar(255) NOT NULL,
  `enable_job_application_candidates` varchar(255) NOT NULL,
  `job_logo` varchar(255) NOT NULL,
  `payroll_logo` varchar(255) NOT NULL,
  `is_payslip_password_generate` int(11) NOT NULL,
  `payslip_password_format` varchar(255) NOT NULL,
  `enable_profile_background` varchar(255) NOT NULL,
  `enable_policy_link` varchar(255) NOT NULL,
  `enable_layout` varchar(255) NOT NULL,
  `job_application_format` mediumtext NOT NULL,
  `technical_competencies` text DEFAULT NULL,
  `organizational_competencies` text DEFAULT NULL,
  `project_email` varchar(255) NOT NULL,
  `holiday_email` varchar(255) NOT NULL,
  `leave_email` varchar(255) NOT NULL,
  `payslip_email` varchar(255) NOT NULL,
  `award_email` varchar(255) NOT NULL,
  `recruitment_email` varchar(255) NOT NULL,
  `announcement_email` varchar(255) NOT NULL,
  `training_email` varchar(255) NOT NULL,
  `task_email` varchar(255) NOT NULL,
  `compact_sidebar` varchar(255) NOT NULL,
  `fixed_header` varchar(255) NOT NULL,
  `fixed_sidebar` varchar(255) NOT NULL,
  `boxed_wrapper` varchar(255) NOT NULL,
  `layout_static` varchar(255) NOT NULL,
  `system_skin` varchar(255) NOT NULL,
  `animation_effect` varchar(255) NOT NULL,
  `animation_effect_modal` varchar(255) NOT NULL,
  `animation_effect_topmenu` varchar(255) NOT NULL,
  `footer_text` varchar(255) NOT NULL,
  `is_ssl_available` varchar(50) NOT NULL,
  `is_active_sub_departments` varchar(10) NOT NULL,
  `default_language` varchar(200) NOT NULL,
  `statutory_fixed` varchar(100) NOT NULL,
  `system_timezone` varchar(200) NOT NULL,
  `system_ip_address` varchar(255) NOT NULL,
  `system_ip_restriction` varchar(200) NOT NULL,
  `google_maps_api_key` mediumtext NOT NULL,
  `module_recruitment` varchar(100) NOT NULL,
  `module_travel` varchar(100) NOT NULL,
  `module_performance` varchar(100) NOT NULL,
  `module_payroll` varchar(10) NOT NULL,
  `module_files` varchar(100) NOT NULL,
  `module_awards` varchar(100) NOT NULL,
  `module_training` varchar(100) NOT NULL,
  `module_inquiry` varchar(100) NOT NULL,
  `module_language` varchar(100) NOT NULL,
  `module_orgchart` varchar(100) NOT NULL,
  `module_accounting` varchar(111) NOT NULL,
  `module_events` varchar(100) NOT NULL,
  `module_goal_tracking` varchar(100) NOT NULL,
  `module_assets` varchar(100) NOT NULL,
  `module_projects_tasks` varchar(100) NOT NULL,
  `module_chat_box` varchar(100) NOT NULL,
  `enable_page_rendered` varchar(255) NOT NULL,
  `enable_current_year` varchar(255) NOT NULL,
  `employee_login_id` varchar(200) NOT NULL,
  `paypal_email` varchar(100) NOT NULL,
  `paypal_sandbox` varchar(10) NOT NULL,
  `paypal_active` varchar(10) NOT NULL,
  `stripe_secret_key` varchar(200) NOT NULL,
  `stripe_publishable_key` varchar(200) NOT NULL,
  `stripe_active` varchar(10) NOT NULL,
  `online_payment_account` int(11) NOT NULL,
  `is_half_monthly` tinyint(1) NOT NULL,
  `half_deduct_month` tinyint(1) NOT NULL,
  `enable_auth_background` varchar(11) NOT NULL,
  `hr_version` varchar(200) NOT NULL,
  `hr_release_date` varchar(100) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_system_setting`
		--
		INSERT INTO `xin_system_setting` (`setting_id`, `application_name`, `default_currency`, `default_currency_id`, `default_currency_symbol`, `show_currency`, `currency_position`, `notification_position`, `notification_close_btn`, `notification_bar`, `enable_registration`, `login_with`, `date_format_xi`, `employee_manage_own_contact`, `employee_manage_own_profile`, `employee_manage_own_qualification`, `employee_manage_own_work_experience`, `employee_manage_own_document`, `employee_manage_own_picture`, `employee_manage_own_social`, `employee_manage_own_bank_account`, `enable_attendance`, `enable_clock_in_btn`, `enable_email_notification`, `payroll_include_day_summary`, `payroll_include_hour_summary`, `payroll_include_leave_summary`, `enable_job_application_candidates`, `job_logo`, `payroll_logo`, `is_payslip_password_generate`, `payslip_password_format`, `enable_profile_background`, `enable_policy_link`, `enable_layout`, `job_application_format`, `technical_competencies`, `organizational_competencies`, `project_email`, `holiday_email`, `leave_email`, `payslip_email`, `award_email`, `recruitment_email`, `announcement_email`, `training_email`, `task_email`, `compact_sidebar`, `fixed_header`, `fixed_sidebar`, `boxed_wrapper`, `layout_static`, `system_skin`, `animation_effect`, `animation_effect_modal`, `animation_effect_topmenu`, `footer_text`, `is_ssl_available`, `is_active_sub_departments`, `default_language`, `statutory_fixed`, `system_timezone`, `system_ip_address`, `system_ip_restriction`, `google_maps_api_key`, `module_recruitment`, `module_travel`, `module_performance`, `module_payroll`, `module_files`, `module_awards`, `module_training`, `module_inquiry`, `module_language`, `module_orgchart`, `module_accounting`, `module_events`, `module_goal_tracking`, `module_assets`, `module_projects_tasks`, `module_chat_box`, `enable_page_rendered`, `enable_current_year`, `employee_login_id`, `paypal_email`, `paypal_sandbox`, `paypal_active`, `stripe_secret_key`, `stripe_publishable_key`, `stripe_active`, `online_payment_account`, `is_half_monthly`, `half_deduct_month`, `enable_auth_background`, `hr_version`, `hr_release_date`, `updated_at`) VALUES
(1, 'SoftifyBD HRM', 'BDT - ?', 1, 'BDT - ?', 'code', 'Prefix', 'toast-top-center', 'true', 'true', 'no', 'username', 'd-M-Y', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', '', 'yes', 'yes', 'yes', 'yes', 1, 'job_logo_1581880059.png', 'payroll_logo_1581880101.png', 0, 'full_name', 'yes', 'yes', 'yes', 'doc,docx,pdf', 'Customer Experience,Marketing,Administration', 'Professionalism,Integrity,Attendance', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'sidebar_layout_hrsale', '', 'fixed-sidebar', 'boxed_layout_hrsale', '', 'skin-default', 'fadeInDown', 'tada', 'tada', 'SoftifyBD', 'yes', '', 'english', 'yes', 'Asia/Dhaka', '52.116.52.120', '', 'AIzaSyB3gP8H3eypotNeoEtezbRiF_f8Zh_p4ck', 'true', 'true', 'yes', 'yes', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', '', 'yes', 'email', 'hrsalesoft-facilitator@gmail.com', 'yes', 'yes', 'sk_test_2XEyr1hQFGByITfQjSwFqNtm', 'pk_test_zVFISCqeQPnniD0ywHBHikMd', 'yes', 1, 0, 1, 'yes', '1.0.3', '2018-03-28', '2018-03-28 04:27:32');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_task_categories`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_task_categories` (
  `task_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`task_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `xin_task_categories`
		--
		INSERT INTO `xin_task_categories` (`task_category_id`, `category_name`, `created_at`) VALUES
(5, 'Development', '17-12-2019 10:44:48'),
(6, 'Bug', '17-12-2019 10:44:55'),
(7, 'Software Frontend Design', '17-12-2019 10:45:01'),
(8, 'Web Design', '17-12-2019 10:45:06'),
(9, 'Graphic Design', '17-12-2019 10:45:12'),
(10, 'QC Test', '17-12-2019 10:45:22'),
(11, 'Research', '15-02-2020 09:33:34'),
(12, 'Content Development', '15-02-2020 09:35:49');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tasks`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tasks` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `project_id` int(111) NOT NULL,
  `created_by` int(111) NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `assigned_to` varchar(255) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `task_hour` varchar(200) NOT NULL,
  `task_progress` varchar(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `task_status` int(5) NOT NULL,
  `task_note` mediumtext NOT NULL,
  `is_notify` int(11) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_tasks`
		--
		INSERT INTO `xin_tasks` (`task_id`, `company_id`, `project_id`, `created_by`, `task_name`, `assigned_to`, `start_date`, `end_date`, `task_hour`, `task_progress`, `description`, `task_status`, `task_note`, `is_notify`, `created_at`) VALUES
(1, 1, 2, 9, 5, 9, '2020-02-16', '2020-02-16', 9, 100, '&lt;p&gt;&lt;ul&gt;&lt;li&gt;MAC Reseller restriction for creating new user when balance is 0.&lt;/li&gt;&lt;li&gt;Settings for this restriction.&lt;/li&gt;&lt;/ul&gt;&lt;/p&gt;', 2, '', 0, '2020-02-16 12:25:44'),
(13, 1, 2, 14, 5, 14, '2020-02-16', '2020-02-16', 5, 50, '&lt;p&gt;&lt;ul&gt;&lt;li&gt;&lt;strong&gt;New Design For Customer Add&lt;/strong&gt;&lt;/li&gt;&lt;li&gt;&lt;strong&gt;New Design For Customer Edit&lt;/strong&gt;&lt;/li&gt;&lt;li&gt;&lt;strong&gt;New Design For Customer Import&lt;/strong&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/p&gt;', 1, '', 0, '2020-02-16 12:59:51'),
(14, 1, 3, 12, 8, 12, '2020-02-16', '2020-02-16', 2, 0, 'Cable TV mailing Enable on form.', 0, '', 0, '2020-02-16 01:05:38'),
(15, 1, 3, 12, 8, 12, '2020-02-16', '2020-02-16', 2, 0, 'Cable TV mailing Enable on form.', 0, '', 0, '2020-02-16 01:07:04'),
(16, 1, 3, 12, 8, 12, '2020-02-16', '2020-02-16', 2, 0, 'Cable TV mailing Enable on form.', 0, '', 0, '2020-02-16 01:10:31'),
(37, 1, 2, 9, 5, 9, '2020-02-17', '2020-02-19', 27, 0, '&lt;ul&gt;&lt;li&gt;Item Category tree for bandwidth item&lt;/li&gt;&lt;li&gt;Last purchase rate suggest as bandwidth sale rate&lt;/li&gt;&lt;li&gt;Zone in reseller&lt;/li&gt;&lt;/ul&gt;', 0, '', 0, '2020-02-17 10:55:12'),
(38, 1, 8, 6, 8, 15, '2020-02-17', '2020-02-17', 4, 50, 'xyz', 1, '', 0, '2020-02-17 11:29:09');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tasks_attachment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tasks_attachment` (
  `task_attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(200) NOT NULL,
  `upload_by` int(255) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_description` mediumtext NOT NULL,
  `attachment_file` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`task_attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tasks_comments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tasks_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(200) NOT NULL,
  `user_id` int(200) NOT NULL,
  `task_comments` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tax_types`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tax_types` (
  `tax_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_tax_types`
		--
		INSERT INTO `xin_tax_types` (`tax_id`, `name`, `rate`, `type`, `description`, `created_at`) VALUES
(1, 'No Tax', 0, 'fixed', 'test', '25-05-2018'),
(2, 'IVU', 2, 'fixed', 'test', '25-05-2018'),
(3, 'VAT', 5, 'percentage', 'testttt', '25-05-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_termination_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_termination_type` (
  `termination_type_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`termination_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_termination_type`
		--
		INSERT INTO `xin_termination_type` (`termination_type_id`, `company_id`, `type`, `created_at`) VALUES
(1, 1, 'Voluntary', '22-03-2018 01:38:41'),
(2, 0, 'Dismissal', '16-02-2020 06:17:39'),
(3, 0, 'Discharge', '17-02-2020 12:04:47'),
(4, 0, 'Resignation', '17-02-2020 12:05:31'),
(5, 0, 'Retirement', '17-02-2020 12:05:53');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_theme_settings`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_theme_settings` (
  `theme_settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `fixed_layout` varchar(200) NOT NULL,
  `fixed_footer` varchar(200) NOT NULL,
  `boxed_layout` varchar(200) NOT NULL,
  `page_header` varchar(200) NOT NULL,
  `footer_layout` varchar(200) NOT NULL,
  `statistics_cards` varchar(200) NOT NULL,
  `animation_style` varchar(100) NOT NULL,
  `theme_option` varchar(100) NOT NULL,
  `dashboard_option` varchar(100) NOT NULL,
  `dashboard_calendar` varchar(100) NOT NULL,
  `login_page_options` varchar(100) NOT NULL,
  `sub_menu_icons` varchar(100) NOT NULL,
  `statistics_cards_background` varchar(200) NOT NULL,
  `employee_cards` varchar(200) NOT NULL,
  `card_border_color` varchar(200) NOT NULL,
  `compact_menu` varchar(200) NOT NULL,
  `flipped_menu` varchar(200) NOT NULL,
  `right_side_icons` varchar(200) NOT NULL,
  `bordered_menu` varchar(200) NOT NULL,
  `form_design` varchar(200) NOT NULL,
  `is_semi_dark` int(11) NOT NULL,
  `semi_dark_color` varchar(200) NOT NULL,
  `top_nav_dark_color` varchar(200) NOT NULL,
  `menu_color_option` varchar(200) NOT NULL,
  `export_orgchart` varchar(100) NOT NULL,
  `export_file_title` mediumtext NOT NULL,
  `org_chart_layout` varchar(200) NOT NULL,
  `org_chart_zoom` varchar(100) NOT NULL,
  `org_chart_pan` varchar(100) NOT NULL,
  PRIMARY KEY (`theme_settings_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_theme_settings`
		--
		INSERT INTO `xin_theme_settings` (`theme_settings_id`, `fixed_layout`, `fixed_footer`, `boxed_layout`, `page_header`, `footer_layout`, `statistics_cards`, `animation_style`, `theme_option`, `dashboard_option`, `dashboard_calendar`, `login_page_options`, `sub_menu_icons`, `statistics_cards_background`, `employee_cards`, `card_border_color`, `compact_menu`, `flipped_menu`, `right_side_icons`, `bordered_menu`, `form_design`, `is_semi_dark`, `semi_dark_color`, `top_nav_dark_color`, `menu_color_option`, `export_orgchart`, `export_file_title`, `org_chart_layout`, `org_chart_zoom`, `org_chart_pan`) VALUES
(1, 'false', 'true', 'false', 'breadcrumb-transparent', 'footer-transparent', 8, 'fadeInDown', 'template_1', 'dashboard_1', '', 'login_page_2', 'fa-check-circle-o', '', '', '', 'true', 'false', 'false', 'false', 'default_square_form', 1, 'bg-primary', 'bg-blue-grey', 'menu-dark', 'true', 'SoftifyBD Ltd.', 't2b', 'true', 'true');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tickets_attachment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tickets_attachment` (
  `ticket_attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(200) NOT NULL,
  `upload_by` int(255) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_description` mediumtext NOT NULL,
  `attachment_file` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`ticket_attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_tickets_comments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_tickets_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(200) NOT NULL,
  `user_id` int(200) NOT NULL,
  `ticket_comments` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_trainers`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_trainers` (
  `trainer_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `designation_id` int(111) NOT NULL,
  `expertise` mediumtext NOT NULL,
  `address` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`trainer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_training`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_training` (
  `training_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `employee_id` varchar(200) NOT NULL,
  `training_type_id` int(200) NOT NULL,
  `trainer_option` int(11) NOT NULL,
  `trainer_id` int(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `finish_date` varchar(200) NOT NULL,
  `training_cost` varchar(200) NOT NULL,
  `training_status` int(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `performance` varchar(200) NOT NULL,
  `remarks` mediumtext NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_training_types`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_training_types` (
  `training_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`training_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_training_types`
		--
		INSERT INTO `xin_training_types` (`training_type_id`, `company_id`, `type`, `created_at`, `status`) VALUES
(1, 1, 'Job Training', '19-03-2018 06:45:47', 1),
(2, 1, 'Workshop', '19-03-2018 06:45:51', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_travel_arrangement_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_travel_arrangement_type` (
  `arrangement_type_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`arrangement_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_travel_arrangement_type`
		--
		INSERT INTO `xin_travel_arrangement_type` (`arrangement_type_id`, `company_id`, `type`, `status`, `created_at`) VALUES
(1, 1, 'Corporation', 1, '19-03-2018 08:45:17'),
(2, 1, 'Guest House', 1, '19-03-2018 08:45:27');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_user_roles`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_user_roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `role_name` varchar(200) NOT NULL,
  `role_access` varchar(200) NOT NULL,
  `role_resources` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_user_roles`
		--
		INSERT INTO `xin_user_roles` (`role_id`, `company_id`, `role_name`, `role_access`, `role_resources`, `created_at`) VALUES
(1, 1, 'Super Admin', 1, '0,103,13,13,201,202,203,372,373,393,393,394,395,396,351,92,88,23,23,204,205,206,231,400,22,12,14,14,207,208,209,232,15,15,210,211,212,233,16,16,213,214,215,234,406,407,408,17,17,216,217,218,235,18,18,219,220,221,236,19,19,222,223,224,237,20,20,225,226,227,238,21,21,228,229,230,239,2,3,3,240,241,242,4,4,243,244,245,249,5,5,246,247,248,6,6,250,251,252,11,11,254,255,256,257,9,9,258,259,260,96,24,25,25,262,263,264,265,26,26,266,267,268,97,98,98,269,270,271,272,99,99,273,274,275,276,27,28,28,397,10,10,253,261,29,29,381,30,30,277,278,279,310,401,401,402,403,31,7,7,280,281,282,2822,311,8,8,283,284,285,46,46,287,288,289,290,286,312,48,49,49,291,292,293,50,51,51,294,295,387,52,52,296,297,388,32,36,36,313,314,37,37,391,404,405,40,41,41,298,299,300,301,42,42,302,303,304,305,43,43,306,307,308,309,104,44,44,315,316,317,318,45,45,319,320,321,322,122,122,331,332,333,106,107,107,334,335,336,108,108,338,339,340,47,53,54,54,341,342,343,344,55,55,345,346,347,56,56,348,349,350,57,60,61,118,62,63,93,71,72,72,352,353,354,73,74,75,75,355,356,357,76,76,358,359,360,77,77,361,362,363,78,79,80,80,364,365,366,81,81,367,368,369,82,83,84,85,86,87,119,119,323,324,325,326,410,411,412,413,414,420,415,416,417,418,419,121,121,120,328,329,330,89,89,370,371,90,91,94,95,110,111,112,113,114,115,116,117,409', '28-02-2018'),
(2, 1, 'Employee', 2, '0,13,202,14,207,208,15,210,16,213,214,17,216,217,18,219,220,19,222,223,20,225,226,21,228,229,3,4,5,6,11,257,9,98,272,99,276,28,10,261,29,401,7,8,46,287,286,312,49,50,36,37,41,301,42,305,43,306,307,44,45,319,320,321,107,108,47,54,341,342,343,95', '21-03-2018'),
(3, 0, 'HR', 2, '0,103,13,13,201,202,203,372,373,393,393,394,395,396,351,92,88,23,23,204,205,206,231,400,22,12,14,14,207,208,209,232,15,15,210,211,212,233,16,16,213,214,215,234,406,407,408,17,17,216,217,218,235,18,18,219,220,221,236,19,19,222,223,224,237,20,20,225,226,227,238,21,21,228,229,230,239,2,3,3,240,241,242,4,4,243,244,245,249,5,5,246,247,248,6,6,250,251,252,11,11,254,255,256,257,9,9,258,259,260,96,24,25,25,262,263,264,265,26,26,266,267,268,97,98,98,269,270,271,272,99,99,273,274,275,276,27,28,28,397,10,10,253,261,29,29,381,30,30,277,278,279,310,401,401,402,403,31,7,7,280,281,282,2822,311,8,8,283,284,285,46,46,287,288,289,290,286,312,48,49,49,291,292,293,50,51,51,294,295,387,52,52,296,297,388,32,36,36,313,314,37,37,391,404,405,40,41,41,298,299,300,301,42,42,302,303,304,305,43,43,306,307,308,309,104,44,44,315,316,317,318,45,45,319,320,321,322,122,122,331,332,333,106,107,107,334,335,336,108,108,338,339,340,47,53,54,54,341,342,343,344,55,55,345,346,347,56,56,348,349,350,71,72,72,352,353,354,73,74,75,75,355,356,357,76,76,358,359,360,77,77,361,362,363,78,79,80,80,364,365,366,81,81,367,368,369,82,83,84,85,86,87,119,119,323,324,325,326,410,411,412,413,414,420,415,416,417,418,419,121,121,120,328,329,330,90,91,95,110,111,112,113,114,115,116,117,409', '15-02-2020'),
(4, 0, 'Director', 1, '0,103,13,13,201,202,203,372,373,393,393,394,395,396,351,92,88,23,23,204,205,206,231,400,22,12,14,14,207,208,209,232,15,15,210,211,212,233,16,16,213,214,215,234,406,407,408,17,17,216,217,218,235,18,18,219,220,221,236,19,19,222,223,224,237,20,20,225,226,227,238,21,21,228,229,230,239,2,3,3,240,241,242,4,4,243,244,245,249,5,5,246,247,248,6,6,250,251,252,11,11,254,255,256,257,9,9,258,259,260,96,24,25,25,262,263,264,265,26,26,266,267,268,97,98,98,269,270,271,272,99,99,273,274,275,276,27,28,28,397,10,10,253,261,29,29,381,30,30,277,278,279,310,401,401,402,403,31,7,7,280,281,282,2822,311,8,8,283,284,285,46,46,287,288,289,290,286,312,48,49,49,291,292,293,50,51,51,294,295,52,52,296,297,32,36,36,313,314,404,405,40,41,41,298,299,300,301,42,42,302,303,304,305,43,43,306,307,308,309,104,44,44,315,316,317,318,45,45,319,320,321,322,122,122,331,332,333,106,107,107,334,335,336,108,108,338,339,340,47,53,54,54,341,342,343,344,55,55,345,346,347,56,56,348,349,350,57,60,61,118,62,63,93,71,72,72,352,353,354,73,74,75,75,355,356,357,76,76,358,359,360,77,77,361,362,363,78,79,80,80,364,365,366,81,81,367,368,369,82,83,84,85,86,87,119,119,323,324,325,326,410,411,412,413,414,420,415,416,417,418,419,121,121,120,328,329,330,89,89,370,371,90,91,94,95,110,111,112,113,114,115,116,117,409', '16-02-2020');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_users`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role` varchar(30) NOT NULL DEFAULT 'administrator',
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_logo` varchar(255) NOT NULL,
  `user_type` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_photo` varchar(255) NOT NULL,
  `profile_background` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(11) NOT NULL,
  `last_login_date` varchar(255) NOT NULL,
  `last_login_ip` varchar(255) NOT NULL,
  `is_logged_in` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `xin_warning_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `xin_warning_type` (
  `warning_type_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`warning_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `xin_warning_type`
		--
		INSERT INTO `xin_warning_type` (`warning_type_id`, `company_id`, `type`, `created_at`) VALUES
(1, 1, 'First Written Warning', '22-03-2018 01:38:02'),
(2, 0, 'Second Written Warning', '16-02-2020 12:56:57'),
(3, 0, 'Final Written Warning', '16-02-2020 12:57:20');


		/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
		/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
		/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;